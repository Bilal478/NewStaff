<?php
namespace App\Http\Controllers\Api\v1\Report_error;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class ReportAnError extends Controller {
	
	public function index(Request $request){
		
		//$neo_settings = DB::select('select * from neostaff_settings');
		//echo json_encode($neo_settings);
		
		$UserID = $request->UserID;
		$Description = $request->Description;
		$Datetime = $request->Datetime;
		$Ip = $request->Ip;
		
		//DB::insert('insert into report_an_error (ID, Ticket_number, UserID, Description, Datetime, Ip) values (?, ?, ?, ?, ?, ?)', [NULL, '0000000', $UserID, $Description, $Datetime, $Ip]);
		
		$id = DB::table('report_an_error')->insertGetId(
         ['Ticket_number' => "0000000",
		 'UserID' => $UserID,
		 'Description' => $Description,
		 'Datetime' => $Datetime,
		 'Ip' => $Ip		 
		 ]);
		

		$Id_length= strlen(strval($id));
		$ticket_number="00000000";
		$ticket = substr($ticket_number, 0, -$Id_length);
		$result = strval($ticket.$id);
		
		DB::update('update report_an_error set Ticket_number = "'.$result.'" where ID = ?', [$id]);
		
		return api_response("Report success", 200);
		
	}

}
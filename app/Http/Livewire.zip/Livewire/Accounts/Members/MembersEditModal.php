<?php

namespace App\Http\Livewire\Accounts\Members;

use App\Models\User;
use App\Models\Team;
use App\Models\Account;
use Livewire\Component;
use App\Rules\AtLeastOneOwner;
use Illuminate\Validation\Rule;
use App\Http\Livewire\Traits\Notifications;
use App\Models\Department;

class MembersEditModal extends Component
{
    use Notifications;

    public $role = '';
    public $userId = null;
    public $firstname = '';
    public $lastname = '';
    public $email = '';
    public $team = '';
    public $department = '';
    public $team_id = [];
    public $department_id = [];

    protected $listeners = [
        'memberEdit' => 'edit',
    ];


    public function edit(User $user)
    {
        $this->userId = $user->id;
        $this->firstname = $user->firstname;
        $this->lastname = $user->lastname;
        $this->email = $user->email;
        $this->role = $this->currentRole;
        // dd(auth()->user());
        // $this->team_id = $user->teams;
        // $this->department_id = $user->departments;
        // dd($user->teams->toArray());
        // dd($user->teams->pivot->team_id);
        foreach ($user->teams as $key => $value) {
           $this->team_id[] =  $value->pivot->team_id;
        }
        foreach ($user->departments as $key => $value) {
           $this->department_id[] =  $value->pivot->department_id;
        }
        $this->dispatchBrowserEvent('open-member-edit-modal');
    }

    public function save()
    {
        // $validatedDate = $this->validate([
        //     'role' => ['required', 'string', Rule::in(['owner', 'manager', 'member']), new AtLeastOneOwner($this->currentRole)],
        //     'team_id' => ['required', 'array'],
        //     'department_id' => ['required', 'array'],
        // ]);
        $this->account
            ->users()
            ->syncWithoutDetaching([$this->userId => ['role' => $this->role]]);

        $this->emit('membersUpdate');

        $user = User::find($this->userId);
        $user->teams()->sync($this->team_id);
        $user->departments()->sync($this->department_id);
        // $team = Team::find($validatedDate['team_id']);
        // $team->users()->sync($this->userId);
        // $department = Department::find($validatedDate['department_id']);
        // $department->users()->sync($this->userId);
        $this->dispatchBrowserEvent('close-member-edit-modal');
        $this->toast('Member Updated', "Member has been updated.");
    }

    public function getCurrentRoleProperty()
    {
        return $this->account
            ->usersWithRole()
            ->where('users.id', $this->userId)
            ->first(['role'])->role;
    }

    public function getAccountProperty()
    {
        return Account::find(session()->get('account_id'));
    }

    public function render()
    {
        return view('livewire.accounts.members.edit-modal');
    }
}

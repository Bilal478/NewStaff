<?php

namespace App\Http\Livewire\Accounts\Members;

use App\Models\User;
use App\Models\Account;
use Livewire\Component;
use Livewire\WithPagination;
use App\Models\AccountInvitation;
use Illuminate\Support\Facades\Gate;
use Illuminate\Database\Eloquent\Builder;
use App\Http\Livewire\Traits\Notifications;

class MembersIndex extends Component
{
    use WithPagination, Notifications;

    public $search = '';
    
    public $filter = 'members';

    protected $listeners = [
        'membersUpdate' => '$refresh',
        'memberInvitationSend' => '$refresh',
    ];

    protected $queryString = [
        'search' => ['except' => ''],
        'page' => ['except' => 1],
    ];

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function updatedFilter()
    {
        $this->reset(['search']);
        $this->resetPage();
    }

    public function memberDelete(User $user)
    {
        if (Gate::denies('delete-account-member', $this->account)) {
            return $this->toast(
                'Unauthorize Action',
                'You need at least one owner on an account.',
                'error'
            );
        }

        $user->activities()->delete();
        $user->tasks()->update(['user_id' => null]);
        $user->projects()->detach();

        if ($user->belongsToManyAccounts()) {
            $this->account->users()->syncWithoutDetaching([$user->id => ['role' => 'removed']]);
        } else {
            $this->account->removeMember($user);
            $user->forceDelete();
        }
    }

    public function inviteDelete(AccountInvitation $accountInvitation)
    {
        $accountInvitation->delete();
    }

    public function getAccountProperty()
    {
        return Account::find(session()->get('account_id'));
    }

    public function render()
    {
        return view('livewire.accounts.members.index', [
            'users' => $this->users(),
        ])->layout('layouts.app', ['title' => 'Members']);
    }

    public function users()
    {
        return $this->filter == 'members'
            ? $this->members()
            : $this->invites();
    }

    public function members()
    {
        return $this->account
            ->usersWithRole()
            ->where('role', '!=', 'removed')
            ->latest()
            ->where(function (Builder $query) {
                return $query->where('firstname', 'like', '%' . $this->search . '%')
                    ->orWhere('lastname', 'like', '%' . $this->search . '%');
            })
            ->paginate(8);
    }

    public function invites()
    {
        return AccountInvitation::latest()
            ->where('email', 'like', '%' . $this->search . '%')
            ->paginate(8);
    }
}

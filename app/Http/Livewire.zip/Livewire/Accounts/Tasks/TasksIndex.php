<?php

namespace App\Http\Livewire\Accounts\Tasks;

use App\Models\Task;
use App\Models\Account;
use Livewire\Component;
use Livewire\WithPagination;
use Illuminate\Support\Facades\Auth;
use App\Http\Livewire\Traits\Notifications;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class TasksIndex extends Component
{
    use WithPagination, AuthorizesRequests, Notifications;

    public $search = '';

    protected $listeners = [
        'tasksUpdate' => '$refresh',
        'activityUpdate'=> '$refresh',
        'projectsUpdate' => '$refresh',
        ];

    protected $queryString = [
        'search' => ['except' => ''],
        'page' => ['except' => 1],
    ];

    public function taskComplete(Task $task)
    {
        $task->update(['completed' => true]);
        $this->toast('Task Complete', "Task has been updated.");
    }
    public function taskProcessing(Task $task)
    {
        $task->update(['completed' => false]);
        $this->toast('Task In progress', "Task has been updated.");
    }

    public function taskDelete(Task $task)
    {
        $task->delete();
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function render()
    {
        return view('livewire.accounts.tasks.index', [
            'tasks' => $this->tasks(),
            ])->layout('layouts.app', ['title' => 'Tasks']);
    }

    public function tasks()
    {
        return Auth::guard('web')->user()->isOwnerOrManager()
            ? $this->tasksForAccount()
            : $this->tasksForUser();
    }

    public function tasksForAccount()
    {
        return Task::where('title', 'like', '%' . $this->search . '%')
            ->with('user:id,firstname,lastname')
            ->latest()
            ->paginate(8);
    }

    public function tasksForUser()
    {
        return Auth::guard('web')->user()
            ->tasks()
            ->where('title', 'like', '%' . $this->search . '%')
            ->with('user:id,firstname,lastname')
            ->latest()
            ->paginate(8);
    }
}

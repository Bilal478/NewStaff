<?php

namespace App\Http\Livewire\Accounts\Tasks;

use App\Models\Activity;
use App\Models\Task;
use Livewire\Component;
use Livewire\WithPagination;


class TasksShow extends Component
{
    use WithPagination;

    public $taskId = null;

    protected $listeners = [
        'taskShow' => 'show',
        'activityUpdate'=> '$refresh',
        'deleteActivity' => 'deleteActivity',
    ];
    public function deleteActivity($id)
    {
        Activity::find($id)->delete();
    }

    public function show($taskId)
    {
        $this->taskId = $taskId;
        $this->dispatchBrowserEvent('open-task-show-modal');
    }

    public function render()
    {
        return view('livewire.accounts.tasks.show', [
            'task' => $this->task,
            'activities' => Activity::where('task_id',$this->taskId)->paginate(5)
        ]);
    }

    public function getTaskProperty()
    {
        return Task::with('user:id,firstname,lastname')
            ->find($this->taskId);
    }
}

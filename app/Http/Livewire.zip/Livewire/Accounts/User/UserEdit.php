<?php

namespace App\Http\Livewire\Accounts\User;

use Livewire\Component;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Http\Livewire\Traits\Notifications;

class UserEdit extends Component
{
    use Notifications;

    public $firstname;
    public $lastname;
    public $email;
    public $password = '';
    public $passwordConfirmation = '';

    public function mount()
    {
        $this->firstname = Auth::guard('web')->user()->firstname;
        $this->lastname = Auth::guard('web')->user()->lastname;
        $this->email = Auth::guard('web')->user()->email;
    }

    public function save()
    {
        $this->validate([
            'firstname' => 'required|max:50',
            'lastname' => 'required|max:50',
            'email' => ['required', 'email', Rule::unique('users')->ignore(Auth::guard('web')->user()->id)],
        ]);

        Auth::guard('web')->user()->update([
            'firstname' => $this->firstname,
            'lastname' => $this->lastname,
            'email' => $this->email,
        ]);

        $this->emitTo('accounts.user.user-info', 'userProfileUpdated');
        $this->toast('Profile Saved', "The changes to your profile has been saved.");
    }

    public function updatePassword()
    {
        $this->validate([
            'password' => 'required|min:8|same:passwordConfirmation',
        ]);

        Auth::guard('web')->user()->update([
            'password' => Hash::make($this->password),
        ]);

        $this->toast('Password Updated', "The password has been updated.");
        $this->reset(['password', 'passwordConfirmation']);
    }

    public function render()
    {
        return view('livewire.accounts.profile.edit')
            ->layout('layouts.app', ['title' => 'My Profile']);
    }
}

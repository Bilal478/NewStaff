<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Card extends Component
{
    public function render()
    {
        return view('components.activities.card');
    }
}

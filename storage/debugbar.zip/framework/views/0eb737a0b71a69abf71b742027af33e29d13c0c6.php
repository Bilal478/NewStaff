<div
    x-data="{show: false, type: 'success', title: '', description: ''}"
    x-show="show"
    x-on:toast.window="show = true; type = $event.detail.type; title = $event.detail.title; description = $event.detail.description; setTimeout(() => { show = false }, $event.detail.duration)"
    x-cloak
    class="fixed bg-white mr-5 mt-5 p-4 right-0 rounded-lg shadow-xl top-0 w-80 border z-30"
>
    <div class="relative flex items-start justify-end">
        <div class="flex-1">
            <div class="flex items-start">
                <div class="pr-4">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.x-circle','data' => ['xShow' => 'type == \'error\'','class' => 'w-6 h-6 text-red-500']]); ?>
<?php $component->withName('svgs.x-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-show' => 'type == \'error\'','class' => 'w-6 h-6 text-red-500']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.check-circle','data' => ['xShow' => 'type == \'success\'','class' => 'w-6 h-6 text-green-500']]); ?>
<?php $component->withName('svgs.check-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-show' => 'type == \'success\'','class' => 'w-6 h-6 text-green-500']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
                <div>
                    <h5 x-text="title" class="text-sm font-semibold text-gray-700 leading-6"></h5>
                    <p x-text="description" class="text-sm text-gray-500 mt-1"></p>
                </div>
            </div>
        </div>
        <button x-on:click="show = false" type="button" class="text-gray-400 hover:text-gray-700">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.x','data' => ['class' => 'h-5 w-5']]); ?>
<?php $component->withName('svgs.x'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'h-5 w-5']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </button>
    </div>
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/notifications/toast.blade.php ENDPATH**/ ?>
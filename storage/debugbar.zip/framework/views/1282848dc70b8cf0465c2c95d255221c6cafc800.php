<div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modals.small','data' => ['xOn:openTaskShowModal.window' => 'open = true','xOn:closeTaskShowModal.window' => 'open = false']]); ?>
<?php $component->withName('modals.small'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-on:open-task-show-modal.window' => 'open = true','x-on:close-task-show-modal.window' => 'open = false']); ?>
        <?php if($task): ?>
        <article class="pt-2 pb-4">
            <div class="flex items-center space-x-4 mb-4">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.tasks.status-badge','data' => ['status' => $task->completed]]); ?>
<?php $component->withName('tasks.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($task->completed)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <div class="flex items-center text-gray-500">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.calendar','data' => ['class' => 'w-4 h-4 mr-1 text-blue-600']]); ?>
<?php $component->withName('svgs.calendar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 mr-1 text-blue-600']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if($task->due_date): ?>
                    <span class="text-xs"><?php echo e($task->due_date->format('M d, Y')); ?></span>
                    <?php else: ?>
                    <span class="text-xs">No due datex</span>
                    <?php endif; ?>
                </div>
                <div class="flex items-center text-gray-500">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.user','data' => ['class' => 'w-4 h-4 mr-1 text-blue-600']]); ?>
<?php $component->withName('svgs.user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 mr-1 text-blue-600']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if($task->user): ?>
                    <span class="block text-left font-montserrat text-xs"><?php echo e($task->user->firstname); ?> <?php echo e($task->user->lastname); ?></span>
                    <?php else: ?>
                    <span class="text-xs">Not assigned</span>
                    <?php endif; ?>
                </div>
                <div style="text-align:center; background-color: #F5F5F5; border-radius: 6px; padding: 2px 0px;" class="w-32 px-3 text-xs text-gray-700">
                    <?php echo e(gmdate("H:i:s", App\Models\Activity::where('project_id',$task->project_id)->where('task_id',$task->id)->sum('seconds'))); ?>

                </div>
            </div>
            <h5 class="font-montserrat font-semibold text-gray-700 mb-4">
                <?php echo e($task->title); ?>

            </h5>
            <p class="text-sm text-gray-500">
                <?php echo e($task->project->title); ?>

            </p>
            <p class="text-sm text-gray-500">
                <?php echo e($task->description); ?>

            </p>
        </article>
        <div class="w-1/2 md:w-full mb-4 md:mb-0" style="display:inline-block;">
            <div class="mx-2 flex items-center justify-center">
                <button wire:click.prevent="subDay()" type="button" class="h-10 appearance-none bg-white block px-3 py-2 border border-gray-300 rounded-md text-gray-600 focus:outline-none hover:border-blue-500 hover:text-blue-600 transition duration-150 ease-in-out text-sm leading-5 mr-2">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.arrow-left','data' => ['class' => 'h-4 w-4']]); ?>
<?php $component->withName('svgs.arrow-left'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'h-4 w-4']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </button>

                <button wire:click.prevent="addDay()" type="button" class="h-10 appearance-none bg-white block px-3 py-2 border border-gray-300 rounded-md text-gray-600 focus:outline-none hover:border-blue-500 hover:text-blue-600 transition duration-150 ease-in-out text-sm leading-5 mr-2">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.arrow-right','data' => ['class' => 'h-4 w-4']]); ?>
<?php $component->withName('svgs.arrow-right'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'h-4 w-4']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </button>
                <div class="flex-1">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.datepicker-without-label','data' => ['wire:model' => 'date','class' => 'w-full','name' => 'date','type' => 'text','clearButton' => false]]); ?>
<?php $component->withName('inputs.datepicker-without-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'date','class' => 'w-full','name' => 'date','type' => 'text','clear-button' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
            </div>
        </div>

        
        <br>
        <br>
        <div>
            <ul>
                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <li><?php echo e($item->date->format('D, F d, Y ')); ?> - <?php echo e("Activity $item->id"); ?> - <?php echo e(gmdate("H:i:s", $item->seconds)); ?>

                    <button type="button" wire:click="$emit('timeEdit','<?php echo e($item->id); ?>','<?php echo e($item->seconds); ?>','<?php echo e($task->title); ?>')">
                        <span class="text-xs text-gray-500"><svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z">
                                </path>
                            </svg></span>
                    </button>

                    
                    <button id="alertConfirm" wire:click.prevent="confirmDeleteActivity(<?php echo e($item->id); ?>)" type="button">


                        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16">
                            </path>
                        </svg>
                    </button>



                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              

                <?php if( $count ==0 ): ?>
                <script>
                  refreshPagintation();           
                </script>
                <?php echo "<p style='color: #737373;'>There aren't activity for this date</p>"; ?>
                <?php endif; ?>
                <br>
            </ul>
            <?php echo e($activities->links()); ?>

        </div>
        <?php endif; ?>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <div>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modals.small2','data' => ['xOn:openActivitiesFormModalShow.window' => 'open = true','xOn:closeActivitiesFormModalShow.window' => 'open = false']]); ?>
<?php $component->withName('modals.small2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-on:open-activities-form-modal-show.window' => 'open = true','x-on:close-activities-form-modal-show.window' => 'open = false']); ?>
            <form wire:submit.prevent="create_activity_time" autocomplete="off">

                <h5 class="font-montserrat font-semibold text-lg text-gray-700 mb-6">
                    Create Activity
                </h5>

                <label for="start_time" class="block text-sm text-gray-500 my-4 leading-5">
                    Date
                </label>

                <div class="flex-1">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.datepicker-without-label-two','data' => ['wire:model' => 'datetimerange','class' => 'w-full','name' => 'datetimerange','type' => 'text','clearButton' => false]]); ?>
<?php $component->withName('inputs.datepicker-without-label-two'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'datetimerange','class' => 'w-full','name' => 'datetimerange','type' => 'text','clear-button' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>

                <?php
                if ($datetimerange > date('Y-m-d')) {
                ?>
                    <span class="mt-4" style="font-size: 13px; color:red;">Cannot be in the future</span>
                <?php
                }
                ?>
                <label for="start_time" class="block mt-4 text-sm text-gray-500 leading-5">
                    Start Time
                </label>
                <div class="mt-1 rounded-md shadow-sm">
                    <input name="seconds_one" id="seconds_one" type="text" step='1' min="00:00:00" max="24:00:00" wire:model.prevent="seconds_one" required="required" class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md placeholder-gray-400 text-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out text-sm leading-5 timepicker_one">
                </div>

                <?php if ($seconds_one > date("HH:mm:ss a")) { ?>
                    <span class="mt-4" style="font-size: 13px; color:red;">Cannot be in the future</span>
                <?php
                }
                ?>
                <label for="end_time" style="padding-top: 15px !important;" class="block text-sm  text-gray-500 leading-5">
                    End Time
                </label>
                <div class="mt-1 rounded-md shadow-sm">
                    <input name="seconds_two" id="seconds_two" type="text" step='1' min="12:00:00" max="24:00:00" wire:model="seconds_two" required="required" class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md placeholder-gray-400 text-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out text-sm leading-5 timepicker_two">
                </div>
                <?php if ($seconds_one > date("HH:mm:ss a")) { ?>
                    <span class="mt-4" style="font-size: 13px; color:red;">Cannot be in the future</span>
                <?php
                }
                ?>

                <div class="flex justify-end mt-2">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.buttons.blue-inline','data' => ['type' => 'submit']]); ?>
<?php $component->withName('buttons.blue-inline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit']); ?>
                        Create Activity
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
            </form>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>

<script>
    $('.timepicker_one').timepicker({

        timeFormat: 'HH:mm:ss a',
        interval: 30,
        dynamic: false,
        dropdown: true,
        scrollbar: true,
        change: tmTotalHrsOnSite

    });

    function tmTotalHrsOnSite() {
        var x = $(".timepicker_one").val();

        document.getElementById('seconds_two').value = '';

        let elementName = $(".timepicker_one").attr('id');
        var data = $(".timepicker_one").val();
        window.livewire.find('<?php echo e($_instance->id); ?>').set(elementName, data);

        var block_time = x.split(':');

        var start_t = parseInt(block_time[1]) + parseInt(30);

        if (start_t == 60) {
            start_t = '00';
            block_time[0] = parseInt(block_time[0]) + parseInt(1);
        }

        $('.timepicker_two').timepicker({
            timeFormat: 'HH:mm:ss a',
            interval: 30,
            dynamic: false,
            dropdown: true,
            scrollbar: true,
            change: tmTotalHrsOnSite_two
        });
        $('.timepicker_two').timepicker('option', 'minTime', new Date(0, 0, 0, block_time[0], start_t, 0));
    }

    function tmTotalHrsOnSite_two() {
        var x = $(".timepicker_two").val();
        let elementName = $(".timepicker_two").attr('id');
        var data = $(".timepicker_two").val();
        window.livewire.find('<?php echo e($_instance->id); ?>').set(elementName, data);
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<script>
    window.addEventListener('show-delete-confirmation', event => {
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this activity!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    Livewire.emit('deleteConfirmed');
                    // Livewire.emit('refreshActivities')
                    swal("Your activity has been deleted!", {
                        icon: "success",
                    });
                }
            });
    });

    function refreshPagintation()
    {
        Livewire.emit('refreshPagination');
    }
</script>
<?php $__env->stopPush(); ?><?php /**PATH /home/medianeo/neostaff/resources/views/livewire/accounts/tasks/show.blade.php ENDPATH**/ ?>
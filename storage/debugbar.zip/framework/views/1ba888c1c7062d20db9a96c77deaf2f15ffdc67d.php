<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.page.title','data' => ['svg' => 'svgs.users']]); ?>
<?php $component->withName('page.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['svg' => 'svgs.users']); ?>
        Members
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
	<?php
		$text='';
		if(!empty($_GET)){
			if($_GET['buy_more_seats']==1){
				$text='Seat';
			}
			else{
				$text = 'Seats';
			}
	?>
			<div class="alert" id="alert">
				<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
					You have purchased <?php echo $_GET['buy_more_seats']; echo ' '.$text; ?> more.
			</div>
			<br>
			<script>
			
			function hidealert(){
				document.getElementById('alert').style.display='none';
			}
			
				setTimeout(hidealert, 3000);
			
			</script>
	<?php
		}
	?>
    <div class="md:flex items-center justify-between pb-8">
        <div class="md:flex items-center md:space-x-4">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.search','data' => ['wire:model.debounce.500ms' => 'search','class' => 'w-full md:w-72','placeholder' => ''.e($filter == 'members' ? 'Search by name or lastname' : 'Search by email').'']]); ?>
<?php $component->withName('inputs.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.debounce.500ms' => 'search','class' => 'w-full md:w-72','placeholder' => ''.e($filter == 'members' ? 'Search by name or lastname' : 'Search by email').'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select-without-label','data' => ['wire:model' => 'filter','name' => 'filter','class' => 'w-full md:w-40 mt-4 md:mt-0']]); ?>
<?php $component->withName('inputs.select-without-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'filter','name' => 'filter','class' => 'w-full md:w-40 mt-4 md:mt-0']); ?>
                <option value="members">Members</option>
                <option value="invites">Invites</option>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>

		
        <button wire:click="$emit('memberInvite')" type="button" class="w-full md:w-auto mt-4 md:mt-0 h-10 text-sm flex items-center rounded-md bg-blue-600 text-white pl-4 pr-6 hover:bg-blue-500 focus:outline-none active:bg-blue-700 transition duration-150 ease-in-out">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.plus','data' => ['class' => 'w-5 h-5 mr-1']]); ?>
<?php $component->withName('svgs.plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 mr-1']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            Invite Member
        </button>	
    </div>

    <div id="miModal" class="modal"> 
        <div class="modal-contenido">
            <a href="#">X</a>
            <div class="py-2 pl-2 pr-2">
               <h5 class="url"></h5>
               <input id="myInput" readonly style="width:540px !important; height: 38px;  border: 1px solid black;" type="text" value="<?php echo e($url); ?>" >
               <span class="tooltiptext" id="text"></span>
               <button title="Copy to clipboard" class="rounded-md bg-blue-600 text-white pr-4 pl-4 py-2" type="button" onclick="myFunction()" onmouseout="outFunc()">
                    Copy text
                   
                </button>
            </div>
           

        
        </div>  
    </div>

    <style>
    .tooltiptext {
  visibility: hidden;
  width: 140px;
  background-color: red;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 5px;
  position: absolute;
  z-index: 1;
  bottom: 150%;
  left: 50%;
  margin-left: -75px;
  opacity: 0;
  transition: opacity 0.3s;
}

 
        .url{
            font-size:15px;
        }
        .modal-contenido{
            background-color: white;
            border-radius:8px;
            width:700px;
            height:100px;
            padding: 10px 20px;
            margin: 0 auto;
            position: relative;
        }
       
        .modal{
            background-color: rgba(0,0,0,0.5);
            position:fixed;
            top:0;
            right:0;
            bottom:0;
            left:0;
            opacity:0;
            pointer-events:none;
            transition: all 1s;
        }
        #miModal:target{
            opacity:1;
            pointer-events:auto;
        }
    </style>

    <?php if($users->count()): ?>
        <div>
            <?php if($filter == 'members'): ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.members.headings','data' => []]); ?>
<?php $component->withName('members.headings'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.members.row','data' => ['user' => $user,'key' => $user->id]]); ?>
<?php $component->withName('members.row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user),'key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user->id)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.invites.headings','data' => []]); ?>
<?php $component->withName('invites.headings'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.invites.row','data' => ['user' => $user,'key' => $user->id]]); ?>
<?php $component->withName('invites.row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user),'key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user->id)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <div class="pt-5">
            <?php echo e($users->links('vendor.pagination.default')); ?>

        </div>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.states.empty-data','data' => ['message' => 'There are no pending invites.']]); ?>
<?php $component->withName('states.empty-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['message' => 'There are no pending invites.']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php $__env->startPush('modals'); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.members.members-edit-modal')->html();
} elseif ($_instance->childHasBeenRendered('NhNxMbV')) {
    $componentId = $_instance->getRenderedChildComponentId('NhNxMbV');
    $componentTag = $_instance->getRenderedChildComponentTagName('NhNxMbV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NhNxMbV');
} else {
    $response = \Livewire\Livewire::mount('accounts.members.members-edit-modal');
    $html = $response->html();
    $_instance->logRenderedChild('NhNxMbV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.members.members-invite')->html();
} elseif ($_instance->childHasBeenRendered('aa1mbmx')) {
    $componentId = $_instance->getRenderedChildComponentId('aa1mbmx');
    $componentTag = $_instance->getRenderedChildComponentTagName('aa1mbmx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('aa1mbmx');
} else {
    $response = \Livewire\Livewire::mount('accounts.members.members-invite');
    $html = $response->html();
    $_instance->logRenderedChild('aa1mbmx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php $__env->stopPush(); ?>
</div>
<script>
function myFunction() {
  var copyText = document.getElementById("myInput");
  copyText.select();
  copyText.setSelectionRange(0, 99999);
  navigator.clipboard.writeText(copyText.value);
  
  var text = document.createTextNode("added text");
  document.getElementById("text").appendChild(text);
}


</script>
<style>
.alert {
  padding: 20px;
  background-color: #0284C7;
  color: white;
  border-radius: 6px;
}

.closebtn {
	margin-left: 15px;
	color: white;
	font-weight: bold;
	float: right;
	font-size: 22px;
	line-height: 20px;
	cursor: pointer;
	transition: 0.3s;
}

.closebtn:hover {
	color: black;
}
</style>
<?php /**PATH /home/medianeo/neostaff/resources/views/livewire/accounts/members/index.blade.php ENDPATH**/ ?>
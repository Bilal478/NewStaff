<div >
<div class="overflow-y-auto">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modals.small','data' => ['xOn:openTaskFormModal.window' => 'open = true','xOn:closeTaskFormModal.window' => 'open = false']]); ?>
<?php $component->withName('modals.small'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-on:open-task-form-modal.window' => 'open = true','x-on:close-task-form-modal.window' => 'open = false']); ?>
        <form wire:submit.prevent="save">
            <h5 class="font-montserrat font-semibold text-lg text-gray-700 mb-6">
                <?php echo e($isEditing ? 'Edit Task' : 'New Task'); ?>

            </h5>
			<?php if($inProject): ?>
				<h5 class="font-montserrat text-center font-semibold text-lg text-gray-700 mb-6">
				<?php echo e($project->title); ?>

				</h5>
			<?php endif; ?>
            <?php if(! $inProject): ?>
            <div class="border-b mb-6"> 
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['wire:model' => 'project_id','label' => 'Project','name' => 'project_id','required' => true]]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'project_id','label' => 'Project','name' => 'project_id','required' => true]); ?>
                    <option value="">Select a project</option>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($project->id); ?>">
                        <?php echo e($project->title); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
				
            </div>
            <?php endif; ?>
			
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.text','data' => ['wire:model.lazy' => 'title','label' => 'Title','name' => 'title','type' => 'text','placeholder' => 'Title','required' => true]]); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'title','label' => 'Title','name' => 'title','type' => 'text','placeholder' => 'Title','required' => true]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.textarea','data' => ['wire:model.lazy' => 'description','label' => 'Description','name' => 'description','type' => 'text','placeholder' => 'Description','required' => true]]); ?>
<?php $component->withName('inputs.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'description','label' => 'Description','name' => 'description','type' => 'text','placeholder' => 'Description','required' => true]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

			<?php   
			
			$users_in_project = DB::table('users')
				->join('project_user', 'users.id', '=', 'project_user.user_id')
				->where('project_user.project_id', $project_id)
				->select('users.*')
				->get();
			
			foreach($users_in_project as $item){
				
			}
			
			?>
			
			<?php if( count($users_in_project) > 0 && $project_id != ''){ ?>
			
            <select style="border: 1px solid grey; border-radius:3px; width:100%; margin-bottom:15px; padding: 3px 0px;" wire:model.lazy="user_id" label="Assignee" name="user_id" required>
                <option value="">Select a Assignee</option>
				
				
				
				<?php $__currentLoopData = $users_in_project->sortBy('firstname'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				
                <option value="<?php echo e($user->id); ?>">
                
                    <?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?>


                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
            </select>
			<?php } if ( count($users_in_project) == 0 && $project_id != ''){
			echo "<h4 style='color:red; padding-bottom: 10px;' >There aren't users assigned to this project</h4>";
			}
			?>
			
            
			
            
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['wire:model.lazy' => 'completed','label' => 'Status','name' => 'completed','required' => true]]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'completed','label' => 'Status','name' => 'completed','required' => true]); ?>
                <option value="">Select status</option>
                <option value="false">In progress</option>
                <option value="true"> Completed </option>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <div class="flex justify-end mt-2">
			
			<?php if ( count($users_in_project) == 0 && $project_id != ''){ ?>
				<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.buttons.blue-inline','data' => ['style' => 'background-color: #7DD3FC !important;','disabled' => true,'type' => 'submit']]); ?>
<?php $component->withName('buttons.blue-inline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['style' => 'background-color: #7DD3FC !important;','disabled' => true,'type' => 'submit']); ?>
                    <?php echo e($isEditing ? 'Update Task' : 'Create Task'); ?>

                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
			
			<?php } if( count($users_in_project) > 0 && $project_id != ''){ ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.buttons.blue-inline','data' => ['type' => 'submit']]); ?>
<?php $component->withName('buttons.blue-inline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit']); ?>
                    <?php echo e($isEditing ? 'Update Task' : 'Create Task'); ?>

                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
			<?php } ?>
            </div>
        </form>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
	</div>	
	
	<div>
		<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modals.date','data' => ['xOn:openActivitiesFormModal.window' => 'open = true','xOn:closeActivitiesFormModal.window' => 'open = false']]); ?>
<?php $component->withName('modals.date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-on:open-activities-form-modal.window' => 'open = true','x-on:close-activities-form-modal.window' => 'open = false']); ?>
		     
			<?php if($inTeam): ?> 
				 <form wire:submit.prevent="createActivity"  autocomplete="off"> 
			<?php endif; ?>
			 
			 <form wire:submit.prevent="create_activity"  autocomplete="off">
			 
            <h5 class="font-montserrat font-semibold text-lg text-gray-700 mb-6">
                New Activity
            </h5>
			
			 <?php if(!$inProject): ?> 
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select_two','data' => ['wire:model.lazy' => 'user_id','label' => 'Assignee','name' => 'user_id','id' => 'user_id']]); ?>
<?php $component->withName('inputs.select_two'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'user_id','label' => 'Assignee','name' => 'user_id','id' => 'user_id']); ?>
                <option value="">Select a Assignee</option>
                <?php $__currentLoopData = App\Models\User::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>">
                    <?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
			<?php endif; ?>
			<?php

			if($user_id != ''){
				
				if( count(App\Models\Task::where('user_id', $user_id)->get()) > 0 ){
			?> 
				<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select_two','data' => ['wire:model.lazy' => 'task_id','label' => 'Task','name' => 'task_id','id' => 'task_id']]); ?>
<?php $component->withName('inputs.select_two'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'task_id','label' => 'Task','name' => 'task_id','id' => 'task_id']); ?>
					<option value="">Select a task</option>
					<?php $__currentLoopData = App\Models\Task::where('user_id', $user_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
			<?php
				}else{
					echo "<h4 style='color:red; margin-top: -20px; padding-bottom: 10px;' >There aren't tasks assigned to this user</h4>";
				}
			}	
			?>
			 
			<label for="start_time" class="block text-sm text-gray-500 my-4 leading-5">
					Date 
				</label>
			
			<div class="flex-1">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.datepicker-without-label-two','data' => ['wire:model' => 'datetimerange','class' => 'w-full','name' => 'datetimerange','type' => 'text','clearButton' => false]]); ?>
<?php $component->withName('inputs.datepicker-without-label-two'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'datetimerange','class' => 'w-full','name' => 'datetimerange','type' => 'text','clear-button' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
			
			<?php	//echo "Seconds: ".$seconds." - Seconds Two:".$seconds_two; ?>

				<label for="start_time" class="block mt-4 text-sm text-gray-500 leading-5">
					Start Time 
					
				</label>
				<div class="mt-1 rounded-md shadow-sm">
                <input name="seconds" id="seconds" type="text" step='1' min="00:00:00" max="24:00:00"
                    wire:model="seconds" required="required"
                    class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md placeholder-gray-400 text-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out text-sm leading-5 timepicker">
				</div>

				<label for="end_time" style="padding-top: 15px !important;" class="block text-sm  text-gray-500 leading-5">
					End Time  
				</label>
				<div class="mt-1 rounded-md shadow-sm">
                <input name="seconds_two" id="seconds_two" type="text" step='1' min="12:00:00" max="24:00:00"
                    wire:model="seconds_two" required="required"
                    class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md placeholder-gray-400 text-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out text-sm leading-5 timepicker_two">
				</div>
			<?php if( count(App\Models\Task::where('user_id', $user_id)->get()) > 0 ){ ?>
            <div class="flex justify-end mt-2">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.buttons.blue-inline','data' => ['type' => 'submit']]); ?>
<?php $component->withName('buttons.blue-inline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit']); ?>
                  Create Activity
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
			
			<?php } else{ ?>
			
			<div class="flex justify-end mt-2">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.buttons.blue-inline','data' => ['style' => 'background-color: #7DD3FC !important;','disabled' => true,'type' => 'submit']]); ?>
<?php $component->withName('buttons.blue-inline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['style' => 'background-color: #7DD3FC !important;','disabled' => true,'type' => 'submit']); ?>
                  Create Activity
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>

          
			<?php 
             
            } ?>
        </form>
		 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
	</div>	
	
	
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.projects.projects-form')->html();
} elseif ($_instance->childHasBeenRendered('C8sDncB')) {
    $componentId = $_instance->getRenderedChildComponentId('C8sDncB');
    $componentTag = $_instance->getRenderedChildComponentTagName('C8sDncB');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('C8sDncB');
} else {
    $response = \Livewire\Livewire::mount('accounts.projects.projects-form');
    $html = $response->html();
    $_instance->logRenderedChild('C8sDncB', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('livewire:load', function (event) {

            Livewire.hook('message.processed', () => {

                $('#activityId').select2();
            });

        });
            $('#activityId').on('change', function (e) {
            let elementName = $(this).attr('id');
            var data = $(this).select2("val");
            // $('#tracking_time').val(data);
            window.livewire.find('<?php echo e($_instance->id); ?>').set(elementName, data);
        });

        $('#activityId').select2();
</script>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script>

    $('.timepicker').timepicker({

            timeFormat: 'HH:mm:ss a',
            interval: 30,
            dynamic: false,
	
            dropdown: true,
            scrollbar: true,
            change: tmTotalHrsOnSite

        });

        function tmTotalHrsOnSite () {
            var x = $(".timepicker").val();
			
			document.getElementById('seconds_two').value = '';
			
            let elementName = $(".timepicker").attr('id');
            var data = $(".timepicker").val();
            window.livewire.find('<?php echo e($_instance->id); ?>').set(elementName, data);
			
				var block_time = x.split(':');
				
				var start_t = parseInt(block_time[1])+parseInt(30);
				
				if(start_t == 60){	start_t = '00';	block_time[0] = parseInt(block_time[0])+parseInt(1);	}
				
				$('.timepicker_two').timepicker({
					timeFormat: 'HH:mm:ss a',
					interval: 30,
					dynamic: false,
					dropdown: true,
					scrollbar: true,
					change: tmTotalHrsOnSite_two
				});		
				$('.timepicker_two').timepicker('option', 'minTime', new Date(0, 0, 0, block_time[0], start_t, 0));
        }
        function tmTotalHrsOnSite_two () {
            var x = $(".timepicker_two").val();
            let elementName = $(".timepicker_two").attr('id');
            var data = $(".timepicker_two").val();
            window.livewire.find('<?php echo e($_instance->id); ?>').set(elementName, data);
        }
</script>
<?php $__env->stopPush(); ?>

<?php /**PATH /home/medianeo/neostaff/resources/views/livewire/accounts/tasks/form.blade.php ENDPATH**/ ?>
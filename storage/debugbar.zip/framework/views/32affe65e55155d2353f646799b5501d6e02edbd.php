<?php $attributes = $attributes->exceptProps([
    'svg' => '',
    'name',
]); ?>
<?php foreach (array_filter(([
    'svg' => '',
    'name',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="p-1 <?php echo e($attributes->get('class')); ?>">
    <button <?php echo e($attributes->whereStartsWith('wire:click')); ?> x-on:click="open = false" type="button" class="w-full text-gray-400 px-3 py-2 flex items-center hover:bg-gray-100 rounded-md hover:text-blue-600">
        <?php if($svg): ?>
            <?php if (isset($component)) { $__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\DynamicComponent::class, ['component' => $svg]); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php if (isset($__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9)): ?>
<?php $component = $__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9; ?>
<?php unset($__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>
        <span class="font-montserrat font-semibold ml-2 text-xs text-gray-700"><?php echo e($name); ?></span>
    </button>
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/dropdowns/context-menu-item.blade.php ENDPATH**/ ?>
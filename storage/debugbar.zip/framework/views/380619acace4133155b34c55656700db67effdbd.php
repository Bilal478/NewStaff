<aside class="fixed bg-white border-r inset-y-0 left-0 w-60 hidden lg:block">
    <nav class="h-full pt-8 flex flex-col justify-between" style="overflow: scroll !important;">
        <div>
            <div class="flex items-center justify-center pb-8">
                <a href="<?php echo e(route('home')); ?>" class="inline-block">
                    <img class="w-28 h-auto" alt="Neostaff" src="<?php echo e(url(asset('images/logo/neostaff-logo.png'))); ?>">
                </a>
            </div>

            <div class="pt-6">
                <ul>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.navigation.sidebar-item','data' => ['route' => 'admin.dashboard','img' => 'svgs.office-building']]); ?>
<?php $component->withName('navigation.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'admin.dashboard','img' => 'svgs.office-building']); ?>
                        Accounts
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.navigation.sidebar-item','data' => ['route' => 'admin.members','img' => 'svgs.users']]); ?>
<?php $component->withName('navigation.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'admin.members','img' => 'svgs.users']); ?>
                        Members
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </ul>
            </div>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.user.user-info')->html();
} elseif ($_instance->childHasBeenRendered('Nmy5a7p')) {
    $componentId = $_instance->getRenderedChildComponentId('Nmy5a7p');
    $componentTag = $_instance->getRenderedChildComponentTagName('Nmy5a7p');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Nmy5a7p');
} else {
    $response = \Livewire\Livewire::mount('admin.user.user-info');
    $html = $response->html();
    $_instance->logRenderedChild('Nmy5a7p', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </nav>
</aside>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/navigation/sidebar-admin.blade.php ENDPATH**/ ?>
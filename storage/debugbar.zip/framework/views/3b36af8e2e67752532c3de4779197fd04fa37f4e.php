<?php $attributes = $attributes->exceptProps([
    'status' => 'completed'
]); ?>
<?php foreach (array_filter(([
    'status' => 'completed'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($status): ?>
    <span class="text-xs bg-green-100 text-green-600 py-1 inline-block w-20 rounded text-center">Completed</span>
<?php else: ?>
    <span class="text-xs bg-gray-100 text-gray-600 py-1 inline-block w-20 rounded text-center">In progress</span>
<?php endif; ?>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/tasks/status-badge.blade.php ENDPATH**/ ?>
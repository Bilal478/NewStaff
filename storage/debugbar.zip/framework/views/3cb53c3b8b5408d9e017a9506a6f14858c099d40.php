<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.page.title','data' => ['svg' => 'svgs.task']]); ?>
<?php $component->withName('page.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['svg' => 'svgs.task']); ?>
        Tasks     <?php 
        
        if(!isset($_GET)){
            print_r($_GET['page']);
            $var = $_GET['page'];
        }
        ?>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <div class="sm:flex items-center justify-between pb-8">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.search','data' => ['wire:model.debounce.500ms' => 'search','class' => 'w-full sm:w-72']]); ?>
<?php $component->withName('inputs.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.debounce.500ms' => 'search','class' => 'w-full sm:w-72']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        <?php if (\Illuminate\Support\Facades\Blade::check('role', ['owner', 'manager'])): ?>
            <button wire:click="$emit('taskCreate')" type="button" class="w-full sm:w-auto mt-4 sm:mt-0 h-10 text-sm flex items-center rounded-md bg-blue-600 text-white pl-4 pr-6 hover:bg-blue-500 focus:outline-none active:bg-blue-700 transition duration-150 ease-in-out">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.plus','data' => ['class' => 'w-5 h-5 mr-1']]); ?>
<?php $component->withName('svgs.plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 mr-1']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                New Task
            </button>
        <?php endif; ?>
    </div>

    <?php if($tasks->count()): ?>
        <div>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.tasks.table-headings','data' => []]); ?>
<?php $component->withName('tasks.table-headings'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.tasks.table-row','data' => ['task' => $task]]); ?>
<?php $component->withName('tasks.table-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['task' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($task)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="pt-5">
            <?php echo e($tasks->links('vendor.pagination.default')); ?>

        </div>
    <?php else: ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('role', ['owner', 'manager'])): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.states.empty-data','data' => ['message' => 'There are no tasks created.']]); ?>
<?php $component->withName('states.empty-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['message' => 'There are no tasks created.']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.states.empty-data','data' => ['message' => 'You don\'t have tasks assigned.']]); ?>
<?php $component->withName('states.empty-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['message' => 'You don\'t have tasks assigned.']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
    <?php $__env->startPush('modals'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.tasks.tasks-form')->html();
} elseif ($_instance->childHasBeenRendered('UGo8zsH')) {
    $componentId = $_instance->getRenderedChildComponentId('UGo8zsH');
    $componentTag = $_instance->getRenderedChildComponentTagName('UGo8zsH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UGo8zsH');
} else {
    $response = \Livewire\Livewire::mount('accounts.tasks.tasks-form');
    $html = $response->html();
    $_instance->logRenderedChild('UGo8zsH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
	<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.tasks.tasks-form2')->html();
} elseif ($_instance->childHasBeenRendered('ogiWkCU')) {
    $componentId = $_instance->getRenderedChildComponentId('ogiWkCU');
    $componentTag = $_instance->getRenderedChildComponentTagName('ogiWkCU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ogiWkCU');
} else {
    $response = \Livewire\Livewire::mount('accounts.tasks.tasks-form2');
    $html = $response->html();
    $_instance->logRenderedChild('ogiWkCU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.tasks.tasks-form-edit')->html();
} elseif ($_instance->childHasBeenRendered('9CkTQxS')) {
    $componentId = $_instance->getRenderedChildComponentId('9CkTQxS');
    $componentTag = $_instance->getRenderedChildComponentTagName('9CkTQxS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9CkTQxS');
} else {
    $response = \Livewire\Livewire::mount('accounts.tasks.tasks-form-edit');
    $html = $response->html();
    $_instance->logRenderedChild('9CkTQxS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.tasks.tasks-show')->html();
} elseif ($_instance->childHasBeenRendered('PL9fmMI')) {
    $componentId = $_instance->getRenderedChildComponentId('PL9fmMI');
    $componentTag = $_instance->getRenderedChildComponentTagName('PL9fmMI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PL9fmMI');
} else {
    $response = \Livewire\Livewire::mount('accounts.tasks.tasks-show');
    $html = $response->html();
    $_instance->logRenderedChild('PL9fmMI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('modals'); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('time-modal')->html();
} elseif ($_instance->childHasBeenRendered('fv8FZvp')) {
    $componentId = $_instance->getRenderedChildComponentId('fv8FZvp');
    $componentTag = $_instance->getRenderedChildComponentTagName('fv8FZvp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fv8FZvp');
} else {
    $response = \Livewire\Livewire::mount('time-modal');
    $html = $response->html();
    $_instance->logRenderedChild('fv8FZvp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php $__env->stopPush(); ?>

</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/livewire/accounts/tasks/index.blade.php ENDPATH**/ ?>
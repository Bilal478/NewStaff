<?php echo e($slot); ?>

<?php /**PATH /home/medianeo/neostaff/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>
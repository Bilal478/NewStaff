<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.page.title-breadcrum','data' => ['svg' => 'svgs.departments','route' => ''.e(route('accounts.departments', ['account' => request()->account])).'']]); ?>
<?php $component->withName('page.title-breadcrum'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['svg' => 'svgs.departments','route' => ''.e(route('accounts.departments', ['account' => request()->account])).'']); ?>
        Departments
         <?php $__env->slot('breadcrum'); ?> 
            <?php echo e($department->title); ?>

         <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <div class="flex flex-wrap -mx-4">
        <div class="w-full xl:w-2/3">
            <div class="bg-white mx-4 mb-8 rounded-md border shadow-sm p-8">
                <div class="pb-8 flex items-start justify-between">
                    <div>
                        <h4 class="font-montserrat font-semibold text-xl text-gray-700 pb-2">
                            <?php echo e($department->title); ?>

                        </h4>
                    </div>
                </div>
            </div>

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.departments.department-tasks', ['department' => $department])->html();
} elseif ($_instance->childHasBeenRendered('jSOFsKP')) {
    $componentId = $_instance->getRenderedChildComponentId('jSOFsKP');
    $componentTag = $_instance->getRenderedChildComponentTagName('jSOFsKP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jSOFsKP');
} else {
    $response = \Livewire\Livewire::mount('accounts.departments.department-tasks', ['department' => $department]);
    $html = $response->html();
    $_instance->logRenderedChild('jSOFsKP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <div class="w-full xl:w-1/3">
            <div class="bg-white mx-4 mb-8 rounded-md border shadow-sm p-6 sm:p-8">
                <h4 class="font-montserrat text-sm font-semibold text-blue-600 pb-4 flex items-center">
                    Members
                </h4>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.departments.department-users-form', ['departmentId' => $department->id])->html();
} elseif ($_instance->childHasBeenRendered('NcXlJF5')) {
    $componentId = $_instance->getRenderedChildComponentId('NcXlJF5');
    $componentTag = $_instance->getRenderedChildComponentTagName('NcXlJF5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NcXlJF5');
} else {
    $response = \Livewire\Livewire::mount('accounts.departments.department-users-form', ['departmentId' => $department->id]);
    $html = $response->html();
    $_instance->logRenderedChild('NcXlJF5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/livewire/accounts/departments/show.blade.php ENDPATH**/ ?>
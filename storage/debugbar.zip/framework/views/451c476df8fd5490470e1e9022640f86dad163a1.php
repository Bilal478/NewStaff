<?php $attributes = $attributes->exceptProps([
    'route' => 'accounts.dashboard',
    'img' => '',
]); ?>
<?php foreach (array_filter(([
    'route' => 'accounts.dashboard',
    'img' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<li class="px-2 py-1">
    <a
        href="<?php echo e(route($route)); ?>"
        class="px-3 py-2 text-sm rounded-md flex items-center <?php echo e(Request::routeIs($route . '*') ? 'bg-gray-100 text-blue-600' : ' text-gray-500 hover:bg-gray-100 hover:text-blue-600'); ?>"
    >
        <?php if (isset($component)) { $__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\DynamicComponent::class, ['component' => $img]); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 mr-2']); ?>
<?php if (isset($__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9)): ?>
<?php $component = $__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9; ?>
<?php unset($__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
       <?php echo e($slot); ?>

    </a>
</li>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/navigation/sidebar-item.blade.php ENDPATH**/ ?>
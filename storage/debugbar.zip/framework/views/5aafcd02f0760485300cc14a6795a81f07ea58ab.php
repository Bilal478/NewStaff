<div>
    <div class="pb-12">
        <h1 class="font-montserrat text-xl font-semibold text-gray-700">
            Accounts
        </h1>
    </div>

    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w-full">
            <div class="bg-white rounded-md border p-6 mb-8">
                <h3 class="text-sm text-gray-700 xl:tracking-widest uppercase mb-4 flex items-center">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.office-building','data' => ['class' => 'w-6 h-6 text-blue-600 mr-3']]); ?>
<?php $component->withName('svgs.office-building'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-6 h-6 text-blue-600 mr-3']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php echo e($account->name); ?>

                </h3>

                <table class="w-full">
                    <tbody>
                        <tr class="border-b">
                            <th class="text-left text-xs px-2 py-4 text-gray-700">Resource</th>
                            <th class="text-left text-xs px-2 py-4 text-gray-700 w-32">Count</th>
                        </tr>
                        <tr class="border-b">
                            <td class="text-sm text-gray-500 px-2 py-4 truncate">Users</td>
                            <td class="text-sm text-gray-500 px-2 py-4"><?php echo e($account->users_count); ?></td>
                        </tr>
                        <tr class="border-b">
                            <td class="text-sm text-gray-500 px-2 py-4 truncate">Projects</td>
                            <td class="text-sm text-gray-500 px-2 py-4"><?php echo e($account->projects_count); ?></td>
                        </tr>
                        <tr class="border-b">
                            <td class="text-sm text-gray-500 px-2 py-4 truncate">Tasks</td>
                            <td class="text-sm text-gray-500 px-2 py-4"><?php echo e($account->tasks_count); ?></td>
                        </tr>
                        <tr>
                            <td class="text-sm text-gray-500 px-2 py-4 truncate">Activities</td>
                            <td class="text-sm text-gray-500 px-2 py-4"><?php echo e($account->activities_count); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/livewire/admin/dashboard.blade.php ENDPATH**/ ?>
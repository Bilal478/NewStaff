<div class="w-full pb-4">
    <div class="uppercase text-xs text-gray-400 font-medium flex items-center">
        <div class="flex-1 px-3">
            Name
        </div>
        <div class="w-56 px-3">
            Email
        </div>
        <div class="w-20 px-3">
            Actions
        </div>
    </div>
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/admins/headings.blade.php ENDPATH**/ ?>
<?php $attributes = $attributes->exceptProps([
    'name',
]); ?>
<?php foreach (array_filter(([
    'name',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div  wire:ignore class="<?php echo e($attributes->get('class')); ?>">
    <div class="relative text-gray-400 focus-within:text-blue-600 rounded-md shadow-sm">
        <select
            id="<?php echo e($name); ?>"
            <?php echo e($attributes->whereStartsWith('wire:model')); ?>

            <?php echo e($attributes->whereStartsWith('autofocus')); ?>

            <?php echo e($attributes->whereStartsWith('required')); ?>

            class="h-10 appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md placeholder-gray-400 text-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out text-sm leading-5"
        >
            <?php echo e($slot); ?>

        </select>
        <div class="absolute inset-y-0 right-0 flex items-center justify-center pr-3 pointer-events-none">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.chevron-down','data' => ['class' => 'w-5 h-5']]); ?>
<?php $component->withName('svgs.chevron-down'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
    </div>

    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php $__env->startPush('scripts'); ?>

<script>
    $(document).ready(function() {
        $('#<?php echo e($name); ?>').select2({
            // placeholder: '<?php echo e(__('Select your option')); ?>',
            // allowClear: true
            // $('#<?php echo e($name); ?>').select2('<?php echo e($name); ?>');
        });
        $("#<?php echo e($name); ?>").select2();
        $('#<?php echo e($name); ?>').on('change', function (e) {
            let elementName = $(this).attr('id');
            var data = $(this).select2("val");
            window.livewire.find('<?php echo e($_instance->id); ?>').set(elementName, data);
        });
    });

    </script>

<?php $__env->stopPush(); ?>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/inputs/select-without-label2.blade.php ENDPATH**/ ?>
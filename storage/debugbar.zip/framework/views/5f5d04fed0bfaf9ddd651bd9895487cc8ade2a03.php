<?php $attributes = $attributes->exceptProps(['project', 'users', 'usersCount', 'tasksCount']); ?>
<?php foreach (array_filter((['project', 'users', 'usersCount', 'tasksCount']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
    <article
        wire:click="projectShow(<?php echo e($project->id); ?>)"
        class="bg-white mx-4 mb-8 rounded-md border shadow-sm px-6 py-4 h-64 flex flex-col justify-between items-start cursor-pointer hover:shadow-md"
    >
        <div class="w-full">
            <div class="mb-4 flex items-center justify-between">
                <span class="px-2 py-1 text-xs bg-purple-100 text-purple-500 rounded"><?php echo e($project->category); ?></span>
                <?php if (\Illuminate\Support\Facades\Blade::check('role', ['owner', 'manager'])): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdowns.context-menu','data' => ['class' => '-mr-2']]); ?>
<?php $component->withName('dropdowns.context-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => '-mr-2']); ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdowns.context-menu-item','data' => ['wire:click.stop' => '$emit(\'projectEdit\', '.e($project->id).')','name' => 'Edit','svg' => 'svgs.edit']]); ?>
<?php $component->withName('dropdowns.context-menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.stop' => '$emit(\'projectEdit\', '.e($project->id).')','name' => 'Edit','svg' => 'svgs.edit']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdowns.context-menu-item','data' => ['wire:click.stop' => 'projectArchive('.e($project->id).')','name' => 'Delete','svg' => 'svgs.trash']]); ?>
<?php $component->withName('dropdowns.context-menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.stop' => 'projectArchive('.e($project->id).')','name' => 'Delete','svg' => 'svgs.trash']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>
            <h4 class="font-montserrat font-semibold text-sm text-gray-700 pb-4 truncate">
                <?php echo e($project->title); ?>

            </h4>
            <div class="h-16 overflow-ellipsis overflow-hidden">
                <p class="text-sm text-gray-500">
                    <?php echo e($project->description); ?>

                </p>
            </div>
        </div>
        <div class="w-full flex items-center justify-between">
            <div class="flex items-center space-x-1">
                <?php if($usersCount >= 1): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.user.avatar','data' => []]); ?>
<?php $component->withName('user.avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php endif; ?>
                <?php if($usersCount >= 2): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.user.avatar','data' => []]); ?>
<?php $component->withName('user.avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php endif; ?>
                <?php if($usersCount > 2): ?>
                    <div class="h-8 w-8 bg-indigo-400 rounded-full text-white flex items-center justify-center text-xs tracking-wider">
                        +<?php echo e($usersCount - 2); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="flex items-center text-sm text-blue-600">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                </svg>
                <?php echo e($tasksCount); ?> tasks
            </div>
        </div>
    </article>
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/projects/card.blade.php ENDPATH**/ ?>
<div class="w-full sm:w-1/2 md:w-1/3 xl:w-1/6 mb-8 hidden sm:block">
    <article class="mx-4 h-full flex items-center justify-center">
        <div class="bg-gray-200 block py-3 rounded-md text-center text-gray-500 text-xs opacity-60 w-full">
            No activity
        </div>
    </article>
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/activities/empty.blade.php ENDPATH**/ ?>
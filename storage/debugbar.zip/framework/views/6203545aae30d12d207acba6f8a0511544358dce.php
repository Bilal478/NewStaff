<?php $attributes = $attributes->exceptProps([
    'avatar' => '',
    'large' => false,
]); ?>
<?php foreach (array_filter(([
    'avatar' => '',
    'large' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($avatar): ?>
    <div class="<?php echo e($large ? 'h-10 w-10' : 'w-8 h-8'); ?> bg-blue-300 rounded-full flex items-center justify-center object-cover overflow-hidden flex-shrink-0">
        <img src="https://i.pravatar.cc/50?img=67">
    </div>
<?php else: ?>
    <div class="<?php echo e($large ? 'h-10 w-10' : 'w-8 h-8'); ?> bg-blue-300 rounded-full flex items-center justify-center flex-shrink-0">
        <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-white fill-current" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
        </svg>
    </div>
<?php endif; ?>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/user/avatar.blade.php ENDPATH**/ ?>
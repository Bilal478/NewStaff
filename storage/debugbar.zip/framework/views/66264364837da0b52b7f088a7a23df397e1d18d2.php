

<div>

    <?php if($showCarousel): ?>
        <div id="myModal" class="modal">
            <span class="close cursor" onclick="closeModal()">&times;</span>
            <div class="modal-content">
                <?php $__currentLoopData = $this->allActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mySlides">
                        <div class="numbertext"><?php echo e($loop->iteration); ?> / <?php echo e($this->allActivity->count()); ?></div>


                        <?php if(count($item->screenshots) > 0): ?>
                            <img src="<?php echo e($item->screenshots->first()->fullPath()); ?>" style="width:100%">

                            <?php if($item->screenshots->first()->fullPath() == 'https://media.neostaff.app/screenshots/00/1234567890.png'): ?>
                                <img class="img_placeholder" src="activity_placeholder.png">
                            <?php endif; ?>
                        <?php else: ?>
                            <img class="img_placeholder" src="activity_placeholder.png"
                                style="width:100%;height: 70vh;">
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                <a class="next" onclick="plusSlides(1)">&#10095;</a>

                <div class="caption-container">
                    <p id="caption"></p>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
      
        // setTimeout(function(){ $("#tiggerImage").click(); }, 3000);

        $(document).ready(function() {});
     
        function openModal() {
            document.getElementById("myModal").style.display = "block";

        }

        function closeModal() {
            document.getElementById("myModal").style.display = "none";
            Array.from(document.querySelectorAll('.activity-img')).forEach(function(el) { 
				el.classList.add('group-hover:opacity-100');
			});

            Array.from(document.querySelectorAll('.article')).forEach(function(el) { 
				el.style.display = "block"; 
			});
        }

        var slideIndex = 1;
        showSlides(slideIndex);

        function plusSlides(n) {
            showSlides(slideIndex += n);
        }

        function currentSlide(n) {
            setTimeout(function() {
                showSlides(slideIndex = n);
            }, 2000);

            showSlides(slideIndex = n);
               
            Array.from(document.querySelectorAll('.activity-img')).forEach(function(el) { 
				el.classList.remove('group-hover:opacity-100');
			});

            Array.from(document.querySelectorAll('.article')).forEach(function(el) { 
				el.style.display = "none"; 
			});     
            
        }

        function showSlides(n) {
            var i;
            var slides = document.getElementsByClassName("mySlides");
            //   var dots = document.getElementsByClassName("demo");
            //   var captionText = document.getElementById("caption");
            if (n > slides.length) {
                slideIndex = 1
            }
            if (n < 1) {
                slideIndex = slides.length
            }
            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
                slides[slideIndex - 1].style.display = "block";
            }
            //   for (i = 0; i < dots.length; i++) {
            //       dots[i].className = dots[i].className.replace(" active", "");
            //   }
            //   dots[slideIndex-1].className += " active";
            //   captionText.innerHTML = dots[slideIndex-1].alt;
        }
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        @media  screen and (min-device-width : 1883px) {
            a.prev {
                margin-left: -337px !important;

            }

            a.next {
                margin-right: -337px !important;

            }

            .numbertext {
                color: #fdfdfd;
                margin-top: -67px !important;
                margin-left: -289px !important;
            }
        }

        @media  screen and (min-device-width : 1602px) {
            a.prev {
                margin-left: -137px !important;

            }

            a.next {
                margin-right: -137px !important;

            }

            .numbertext {
                color: #fdfdfd;
                margin-top: -37px !important;
                margin-left: -189px !important;
            }
        }

        @media  screen and (min-device-width : 1527px) {
            a.prev {
                color: rgb(255, 254, 254) !important
            }

            a.next {
                color: rgb(255, 255, 255) !important
            }

            .numbertext {
                color: #ffffff !important;
                margin-top: -17px !important;
                margin-left: -89px !important;
            }
        }

        * {
            box-sizing: border-box;
        }

        .row>.column {
            padding: 0 8px;
        }

        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        .column {
            float: left;
            width: 25%;
        }

        /* The Modal (background) */
        .modal {
            /* display: none; */
            position: fixed;
            z-index: 1;
            padding-top: 100px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: black;
        }

        /* Modal Content */
        .modal-content {
            position: relative;
            background-color: #fefefe;
            margin: auto;
            padding: 0;
            width: 90%;
            max-width: 1200px;
        }

        /* The Close Button */
        .close {
            color: white;
            position: absolute;
            top: 10px;
            right: 25px;
            font-size: 35px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #999;
            text-decoration: none;
            cursor: pointer;
        }

        .mySlides {
            display: none;
        }

        .cursor {
            cursor: pointer;
        }

        /* Next & previous buttons */
        .prev,
        .next {
            cursor: pointer;
            position: absolute;
            top: 50%;
            width: auto;
            padding: 16px;
            margin-top: -50px;
            color: rgb(255, 255, 255);
            font-weight: bold;
            font-size: 24px;
            transition: 0.6s ease;
            border-radius: 0 3px 3px 0;
            user-select: none;
            -webkit-user-select: none;
            background-color: rgba(0, 0, 0, 0.8);
        }

        /* Position the "next button" to the right */
        .next {
            right: 0;
            border-radius: 3px 0 0 3px;
        }

        /* On hover, add a black background color with a little bit see-through */
        .prev:hover,
        .next:hover {
            /* background-color: rgba(248, 248, 248, 0.8); */
        }

        /* Number text (1/3 etc) */
        .numbertext {
            color: #000000;
            font-size: 20px;
            font-weight: 900;
            padding: 8px 12px;
            position: absolute;
            top: 0;
        }

        img {
            margin-bottom: -4px;
        }

        .caption-container {
            text-align: center;
            background-color: black;
            padding: 2px 16px;
            color: white;
        }

        .demo {
            opacity: 0.6;
        }

        .active,
        .demo:hover {
            opacity: 1;
        }

        img.hover-shadow {
            transition: 0.3s;
        }

        .hover-shadow:hover {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        }
    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/medianeo/neostaff/resources/views/livewire/accounts/screenshots/show-carousel.blade.php ENDPATH**/ ?>
<img src="<?php echo e(url(asset('images/logo/neostaff-icon.png'))); ?>" alt="NeoStaff">
<?php /**PATH /home/medianeo/neostaff/resources/views/components/logo.blade.php ENDPATH**/ ?>
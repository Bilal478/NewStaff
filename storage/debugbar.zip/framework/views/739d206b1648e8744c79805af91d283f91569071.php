<svg xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?> fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
</svg>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/svgs/chevron-right.blade.php ENDPATH**/ ?>
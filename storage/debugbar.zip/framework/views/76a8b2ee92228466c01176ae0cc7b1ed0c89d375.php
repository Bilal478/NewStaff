<div>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modals.small','data' => ['xOn:openActivitiesFormModal2.window' => 'open = true','xOn:closeActivitiesFormModal2.window' => 'open = false']]); ?>
<?php $component->withName('modals.small'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-on:open-activities-form-modal-2.window' => 'open = true','x-on:close-activities-form-modal-2.window' => 'open = false']); ?>
		<form wire:submit.prevent="create_activity"  autocomplete="off">	 
			
			<h4 class="font-montserrat text-center font-semibold text-lg text-gray-700 mb-6">
				<?php echo e($task['title']); ?>

			</h4>
			
			<h5 class="font-montserrat font-semibold text-lg text-gray-700 mb-6">
				Create Activity			
			</h5>
			
			<label for="start_time" class="block text-sm text-gray-500 my-4 leading-5">
				Date 
			</label>
			
			<div class="flex-1">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.datepicker-without-label-two','data' => ['wire:model' => 'datetimerange','class' => 'w-full','name' => 'datetimerange','type' => 'text','clearButton' => false]]); ?>
<?php $component->withName('inputs.datepicker-without-label-two'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'datetimerange','class' => 'w-full','name' => 'datetimerange','type' => 'text','clear-button' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
			
			<?php	//echo "Seconds: ".$seconds_one_task." - Seconds Two:".$seconds_two_task; ?>

				<label for="start_time" class="block mt-4 text-sm text-gray-500 leading-5">
					Start Time 
				</label>
				<div class="mt-1 rounded-md shadow-sm">
                <input name="seconds_one_task" id="seconds_one_task" type="text" step='1' min="00:00:00" max="24:00:00"
                    wire:model="seconds_one_task" required="required"
                    class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md placeholder-gray-400 text-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out text-sm leading-5 timepicker_one_task">
				</div>

				<label for="end_time" style="padding-top: 15px !important;" class="block text-sm  text-gray-500 leading-5">
					End Time  
				</label>
				<div class="mt-1 rounded-md shadow-sm">
                <input name="seconds_two_task" id="seconds_two_task" type="text" step='1' min="12:00:00" max="24:00:00"
                    wire:model="seconds_two_task" required="required"
                    class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md placeholder-gray-400 text-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out text-sm leading-5 timepicker_two_task">
				</div>
				
			<div class="flex justify-end mt-2">
				<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.buttons.blue-inline','data' => ['type' => 'submit']]); ?>
<?php $component->withName('buttons.blue-inline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit']); ?>
				  Create Activity
				 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
			</div>
		</form>
	 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</div>	
	<?php $__env->startPush('scripts'); ?>
<script>
    $('.timepicker_one_task').timepicker({

            timeFormat: 'HH:mm:ss a',
            interval: 30,
            dynamic: false,
            dropdown: true,
            scrollbar: true,
            change: tmTotalHrsOnSite

        });

        function tmTotalHrsOnSite () {
            var x = $(".timepicker_one_task").val();
			
			document.getElementById('seconds_two_task').value = '';
			
            let elementName = $(".timepicker_one_task").attr('id');
            var data = $(".timepicker_one_task").val();
            window.livewire.find('<?php echo e($_instance->id); ?>').set(elementName, data);
			
				var block_time = x.split(':');
				
				var start_t = parseInt(block_time[1])+parseInt(30);
				
				if(start_t == 60){	start_t = '00';	block_time[0] = parseInt(block_time[0])+parseInt(1);	}
				
				$('.timepicker_two_task').timepicker({
					timeFormat: 'HH:mm:ss a',
					interval: 30,
					dynamic: false,
					dropdown: true,
					scrollbar: true,
					change: tmTotalHrsOnSite_two
				});
				
	$('.timepicker_two_task').timepicker('option', 'minTime', new Date(0, 0, 0, block_time[0], start_t, 0));
			
        }
        function tmTotalHrsOnSite_two () {
            var x = $(".timepicker_two_task").val();
            let elementName = $(".timepicker_two_task").attr('id');
            var data = $(".timepicker_two_task").val();
            window.livewire.find('<?php echo e($_instance->id); ?>').set(elementName, data);
			
        }
		
</script>
<?php $__env->stopPush(); ?>


<?php /**PATH /home/medianeo/neostaff/resources/views/livewire/accounts/tasks/form2.blade.php ENDPATH**/ ?>
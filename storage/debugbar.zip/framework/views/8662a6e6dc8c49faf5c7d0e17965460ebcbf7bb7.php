<div x-data="{ open: false }" class="relative px-2">
    <button x-on:click="open = true" type="button"
        class="flex items-center px-3 py-2 w-full rounded-md hover:bg-gray-100"
        :class="{ 'bg-gray-100': open === true }">
        <div class="bg-blue-300 h-9 w-9 rounded-sm flex items-center justify-center">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.office-building','data' => ['class' => 'w-6 h-6 text-white']]); ?>
<?php $component->withName('svgs.office-building'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-6 h-6 text-white']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <div class="flex-1 ml-2 truncate flex flex-col justify-center items-start">
            <h2 class="text-gray-800 text-sm truncate">
                <?php echo e($currentAccount->name); ?>

            </h2>
            <span class="text-xs text-gray-400">Company</span>
        </div>
    </button>

    
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/livewire/accounts/account/info.blade.php ENDPATH**/ ?>
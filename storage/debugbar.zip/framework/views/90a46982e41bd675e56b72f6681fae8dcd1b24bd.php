<div class="mx-4 mb-8">
    <?php if (\Illuminate\Support\Facades\Blade::check('role', ['owner', 'manager'])): ?>
        <div class="flex items-center justify-end mb-8">
            <?php if (\Illuminate\Support\Facades\Blade::check('role', ['owner', 'manager'])): ?>
            <button wire:click="$emit('projectCreate')" type="button"
                class="w-full sm:w-auto mt-4 sm:mt-0 h-10 text-sm flex items-center rounded-md bg-blue-600 text-white pl-4 pr-6 hover:bg-blue-500 focus:outline-none active:bg-blue-700 transition duration-150 ease-in-out mr-2">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.plus','data' => ['class' => 'w-5 h-5 mr-1']]); ?>
<?php $component->withName('svgs.plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 mr-1']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                New Project
            </button>
            <?php endif; ?>
            <button wire:click="$emit('taskCreate')" type="button" class="w-full sm:w-auto h-10 text-sm flex items-center rounded-md bg-blue-600 text-white pl-4 pr-6 hover:bg-blue-500 focus:outline-none active:bg-blue-700 transition duration-150 ease-in-out">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.plus','data' => ['class' => 'w-5 h-5 mr-1']]); ?>
<?php $component->withName('svgs.plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 mr-1']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                New Task
            </button>
        </div>
    <?php endif; ?>
    <?php if($tasks->count()): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.tasks.table-headings','data' => []]); ?>
<?php $component->withName('tasks.table-headings'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.tasks.table-row','data' => ['task' => $task]]); ?>
<?php $component->withName('tasks.table-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['task' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($task)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="pt-5">
            <?php echo e($tasks->links('vendor.pagination.default')); ?>

        </div>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.states.empty-data','data' => ['message' => 'This department doesn\'t have tasks.']]); ?>
<?php $component->withName('states.empty-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['message' => 'This department doesn\'t have tasks.']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php $__env->startPush('modals'); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.tasks.tasks-form', ['department' => $department])->html();
} elseif ($_instance->childHasBeenRendered('0qqe72u')) {
    $componentId = $_instance->getRenderedChildComponentId('0qqe72u');
    $componentTag = $_instance->getRenderedChildComponentTagName('0qqe72u');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0qqe72u');
} else {
    $response = \Livewire\Livewire::mount('accounts.tasks.tasks-form', ['department' => $department]);
    $html = $response->html();
    $_instance->logRenderedChild('0qqe72u', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.tasks.tasks-show')->html();
} elseif ($_instance->childHasBeenRendered('GjKaWhA')) {
    $componentId = $_instance->getRenderedChildComponentId('GjKaWhA');
    $componentTag = $_instance->getRenderedChildComponentTagName('GjKaWhA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GjKaWhA');
} else {
    $response = \Livewire\Livewire::mount('accounts.tasks.tasks-show');
    $html = $response->html();
    $_instance->logRenderedChild('GjKaWhA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.tasks.tasks-form-edit')->html();
} elseif ($_instance->childHasBeenRendered('BoxvR0Q')) {
    $componentId = $_instance->getRenderedChildComponentId('BoxvR0Q');
    $componentTag = $_instance->getRenderedChildComponentTagName('BoxvR0Q');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BoxvR0Q');
} else {
    $response = \Livewire\Livewire::mount('accounts.tasks.tasks-form-edit');
    $html = $response->html();
    $_instance->logRenderedChild('BoxvR0Q', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/livewire/accounts/departments/tasks.blade.php ENDPATH**/ ?>
<aside class="fixed bg-white border-r inset-y-0 left-0 w-60 hidden lg:block">
    <nav class="h-full pt-8 flex flex-col justify-between" style="overflow-y: scroll !important;">
        <div>
            <div class="flex items-center justify-center pb-8">
                <a href="<?php echo e(route('home')); ?>" class="inline-block">
                    <img class="w-28 h-auto" alt="Neostaff" src="<?php echo e(url(asset('images/logo/neostaff-logo.png'))); ?>">
                </a>
            </div>

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.account.account-info')->html();
} elseif ($_instance->childHasBeenRendered('t9UIt1O')) {
    $componentId = $_instance->getRenderedChildComponentId('t9UIt1O');
    $componentTag = $_instance->getRenderedChildComponentTagName('t9UIt1O');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('t9UIt1O');
} else {
    $response = \Livewire\Livewire::mount('accounts.account.account-info');
    $html = $response->html();
    $_instance->logRenderedChild('t9UIt1O', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <div class="pt-6">
                <ul>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.navigation.sidebar-item','data' => ['route' => 'accounts.dashboard','img' => 'svgs.chart']]); ?>
<?php $component->withName('navigation.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'accounts.dashboard','img' => 'svgs.chart']); ?>
                        Dashboard
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.navigation.sidebar-item','data' => ['route' => 'accounts.activities','img' => 'svgs.computer']]); ?>
<?php $component->withName('navigation.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'accounts.activities','img' => 'svgs.computer']); ?>
                        Activities
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.navigation.sidebar-item','data' => ['route' => 'accounts.tasks','img' => 'svgs.task']]); ?>
<?php $component->withName('navigation.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'accounts.tasks','img' => 'svgs.task']); ?>
                        Tasks
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.navigation.sidebar-item','data' => ['route' => 'accounts.projects','img' => 'svgs.folder']]); ?>
<?php $component->withName('navigation.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'accounts.projects','img' => 'svgs.folder']); ?>
                        Projects
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.navigation.sidebar-item','data' => ['route' => 'accounts.reports','img' => 'svgs.report']]); ?>
<?php $component->withName('navigation.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'accounts.reports','img' => 'svgs.report']); ?>
                        Weekly Report
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </ul>
            </div>

            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'owner')): ?>
            <div class="pt-6">
                <h4 class="px-4 uppercase text-xs text-gray-400 font-semibold tracking-wider pb-2">
                    Admin
                </h4>
                <ul>
                    
                    
                    <li class="px-2 py-1">
                        <a href="<?php echo e(url('/departments')); ?>"
                            class="px-3 py-2 text-sm rounded-md flex items-center  text-gray-500 hover:bg-gray-100 hover:text-blue-600">
                            <svg   id="Capa_1"   class="w-5 h-5 mr-2"   viewBox="0 0 512 512"   xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="m437.35 409.687c6.103-8.851 9.688-19.567 9.688-31.108v-22.635c0-25.096-16.919-46.301-39.945-52.846v-62.098h-136.093v-30h68.047v-43.305c0-26.128-15.505-48.691-37.79-59.008 6.103-8.851 9.688-19.567 9.688-31.108v-22.635c-.001-30.297-24.648-54.944-54.945-54.944s-54.944 24.647-54.944 54.944v22.635c0 11.541 3.584 22.257 9.688 31.108-22.285 10.318-37.79 32.88-37.79 59.008v43.305h68.046v30h-136.093v62.098c-23.026 6.546-39.945 27.75-39.945 52.846v22.635c0 11.541 3.584 22.257 9.688 31.108-22.285 10.318-37.789 32.88-37.789 59.008v43.305h438.279v-43.305c0-26.128-15.505-48.69-37.79-59.008zm-206.294-354.743c0-13.754 11.19-24.944 24.944-24.944s24.944 11.19 24.944 24.944v22.635c0 13.754-11.19 24.944-24.944 24.944s-24.944-11.19-24.944-24.944zm-28.103 112.751c0-19.299 15.701-35 35-35h36.094c19.299 0 35 15.701 35 35v13.305h-106.094zm214.085 188.249v22.635c0 13.754-11.19 24.944-24.945 24.944-13.754 0-24.944-11.19-24.944-24.944v-22.635c0-13.754 11.19-24.944 24.944-24.944 13.755 0 24.945 11.19 24.945 24.944zm-39.945-84.944v32.098c-23.026 6.546-39.944 27.75-39.944 52.846v22.635c0 11.541 3.584 22.257 9.688 31.108-8.846 4.096-16.627 10.112-22.789 17.526-6.162-7.415-13.944-13.431-22.79-17.526 6.103-8.851 9.688-19.567 9.688-31.108v-22.635c0-25.096-16.918-46.3-39.944-52.846v-32.098zm-121.093 60c13.754 0 24.944 11.19 24.944 24.944v22.635c0 13.754-11.19 24.944-24.944 24.944s-24.944-11.19-24.944-24.944v-22.635c0-13.754 11.19-24.944 24.944-24.944zm-15-60v32.098c-23.026 6.546-39.944 27.75-39.944 52.846v22.635c0 11.541 3.584 22.257 9.688 31.108-8.846 4.096-16.628 10.112-22.79 17.526-6.162-7.415-13.943-13.43-22.789-17.526 6.103-8.851 9.688-19.567 9.688-31.108v-22.635c0-25.096-16.918-46.3-39.944-52.846v-32.098zm-146.038 84.944c0-13.754 11.19-24.944 24.945-24.944 13.754 0 24.944 11.19 24.944 24.944v22.635c0 13.754-11.19 24.944-24.944 24.944-13.755 0-24.945-11.19-24.945-24.944zm77.991 126.056h-106.093v-13.305c0-19.299 15.701-35 35-35h36.093c19.299 0 35 15.701 35 35zm136.094 0h-106.094v-13.305c0-19.299 15.701-35 35-35h36.094c19.299 0 35 15.701 35 35zm136.093 0h-106.093v-13.305c0-19.299 15.701-35 35-35h36.093c19.299 0 35 15.701 35 35z" />
                            </svg>
                            Departments
                        </a>
                    </li>
                    
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.navigation.sidebar-item','data' => ['route' => 'accounts.teams','img' => 'svgs.team']]); ?>
<?php $component->withName('navigation.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'accounts.teams','img' => 'svgs.team']); ?>
                        Teams
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.navigation.sidebar-item','data' => ['route' => 'accounts.members','img' => 'svgs.users']]); ?>
<?php $component->withName('navigation.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'accounts.members','img' => 'svgs.users']); ?>
                        Members
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
					
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.navigation.sidebar-item','data' => ['route' => 'accounts.settings','img' => 'svgs.settings']]); ?>
<?php $component->withName('navigation.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'accounts.settings','img' => 'svgs.settings']); ?>
                        Settings
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
					
					<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.navigation.sidebar-item','data' => ['route' => 'accounts.billing','img' => 'svgs.folder']]); ?>
<?php $component->withName('navigation.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'accounts.billing','img' => 'svgs.folder']); ?>
                        Membership
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.user.user-info')->html();
} elseif ($_instance->childHasBeenRendered('BQsoUrn')) {
    $componentId = $_instance->getRenderedChildComponentId('BQsoUrn');
    $componentTag = $_instance->getRenderedChildComponentTagName('BQsoUrn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BQsoUrn');
} else {
    $response = \Livewire\Livewire::mount('accounts.user.user-info');
    $html = $response->html();
    $_instance->logRenderedChild('BQsoUrn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </nav>
</aside>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/navigation/sidebar.blade.php ENDPATH**/ ?>
<?php $attributes = $attributes->exceptProps([
    'text',
    'type' => 'button'
]); ?>
<?php foreach (array_filter(([
    'text',
    'type' => 'button'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="block w-full rounded-md shadow-sm">
    <button
        type="<?php echo e($type); ?>"
        <?php echo e($attributes->whereStartsWith('wire:click')); ?>

        class="flex justify-center w-full px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-500 focus:outline-none focus:border-blue-700 focus:ring-blue active:bg-blue-700 transition duration-150 ease-in-out">
        <?php echo e($text); ?>

    </button>
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/buttons/blue-full.blade.php ENDPATH**/ ?>
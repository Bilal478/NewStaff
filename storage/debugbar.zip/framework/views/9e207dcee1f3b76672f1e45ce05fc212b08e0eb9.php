<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <?php if(isset($title)): ?>
            <title><?php echo e($title); ?> - <?php echo e(config('app.name')); ?></title>
        <?php else: ?>
            <title><?php echo e(config('app.name')); ?></title>
        <?php endif; ?>

        <link rel="shortcut icon" href="<?php echo e(url(asset('neostaff-icon.png'))); ?>">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,600;0,700;1,400;1,600;1,700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(url(mix('css/app.css'))); ?>">
        <?php echo \Livewire\Livewire::styles(); ?>


        <script src="<?php echo e(url(mix('js/app.js'))); ?>" defer></script>
    </head>

    <body class="bg-gray-50">
        <div class="flex flex-col justify-center min-h-screen py-12 bg-gray-50 px-6 lg:px-8">
		<?php if(isset($slot)): ?>
		   <?php echo e($slot); ?>

		<?php else: ?>
			<?php echo $__env->yieldContent('content'); ?>
		<?php endif; ?>
        </div>

        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html>
<?php /**PATH /home/medianeo/neostaff/resources/views/layouts/auth.blade.php ENDPATH**/ ?>
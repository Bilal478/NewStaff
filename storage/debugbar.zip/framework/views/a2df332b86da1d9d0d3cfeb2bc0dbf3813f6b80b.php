<div class="flex items-start flex-wrap -mx-4 pt-8 border-t">
    <div class="w-full md:w-1/3">
        <div class="mx-4 mb-4 md:mb-0">
            <h6 class="font-montserrat font-semibold text-sm text-gray-700 pb-3">Danger Zone</h6>
            <p class="text-sm text-gray-500">Delete account, this action can't be undone.</p>
        </div>
    </div>
    <div class="w-full md:w-2/3">
        <article class="bg-white mx-4 mb-8 rounded-md border shadow-sm px-6 py-4">
            <form wire:submit.prevent="delete">
                <p class="text-sm text-gray-500 leading-5 flex items-center">
                    <span class="text-xl text-gray-700 mr-2">&bull;</span>Delete all members.
                </p>
                <p class="text-sm text-gray-500 leading-5 flex items-center">
                    <span class="text-xl text-gray-700 mr-2">&bull;</span>Delete all projects.
                </p>
                <p class="text-sm text-gray-500 leading-5 flex items-center">
                    <span class="text-xl text-gray-700 mr-2">&bull;</span>Delete all tasks.
                </p>
                <p class="text-sm text-gray-500 leading-5 flex items-center">
                    <span class="text-xl text-gray-700 mr-2">&bull;</span>Delete all activities.
                </p>
                <div class="flex justify-end mt-2">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.buttons.red-inline','data' => ['type' => 'submit']]); ?>
<?php $component->withName('buttons.red-inline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit']); ?>
                        Delete Account
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
            </form>
        </article>
    </div>
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/livewire/accounts/settings/delete.blade.php ENDPATH**/ ?>
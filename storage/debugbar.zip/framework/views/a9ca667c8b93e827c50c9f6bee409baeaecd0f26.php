<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modals.small','data' => ['xOn:openDeleteImageActivityModal.window' => 'open = true','xOn:closeDeleteImageActivityModal.window' => 'open = false']]); ?>
<?php $component->withName('modals.small'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-on:open-delete-image-activity-modal.window' => 'open = true','x-on:close-delete-image-activity-modal.window' => 'open = false']); ?>
    
    <h3>Do you want delete the image?</h3>
    <div class="flex items-center flex-wrap -mx-2 pb-8">
        <div class="w-full mt-6 ">
            <button type="button" wire:click.prevent="deleteImageActivity()"
                class="h-10 px-5  text-white transition-colors duration-150 bg-blue-600 rounded-lg focus:shadow-outline hover:bg-blue-500">Yes</button>
            <button type="button"  wire:click.prevent="closeModal()"
                class="h-10 px-5 text-white transition-colors duration-150 bg-red-600 rounded-lg focus:shadow-outline hover:bg-red-500">No</button>
        </div>
    </div>

 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
    <script></script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/medianeo/neostaff/resources/views/livewire/accounts/activities/delete-image-activity-modal.blade.php ENDPATH**/ ?>
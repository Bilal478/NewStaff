<?php

use App\Models\Account;
use App\Models\User;

$account_user = DB::table('account_user')
    ->select('account_id')
    ->where('user_id', auth()->user()->id)
    ->get();

$account_id = $account_user[0]->account_id;

$account = Account::where('id', $account_id)
    ->select('name')
    ->get();
?>
<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.page.title','data' => ['svg' => 'svgs.computer']]); ?>
<?php $component->withName('page.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['svg' => 'svgs.computer']); ?>
        Activities
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <div class="flex items-center flex-wrap -mx-2 pb-8">
        <div class="w-full md:w-1/3 lg:w-1/4 mb-4 md:mb-0">
            <div class="mx-2 flex items-center justify-center">
                <button wire:click.prevent="subDay()" type="button" class="btnMostrar h-10 appearance-none bg-white block px-3 py-2 border border-gray-300 rounded-md text-gray-600 focus:outline-none hover:border-blue-500 hover:text-blue-600 transition duration-150 ease-in-out text-sm leading-5 mr-2">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.arrow-left','data' => ['class' => 'h-4 w-4']]); ?>
<?php $component->withName('svgs.arrow-left'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'h-4 w-4']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </button>
                <button wire:click.prevent="addDay()" type="button" class="btnMostrar h-10 appearance-none bg-white block px-3 py-2 border border-gray-300 rounded-md text-gray-600 focus:outline-none hover:border-blue-500 hover:text-blue-600 transition duration-150 ease-in-out text-sm leading-5 mr-2">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.arrow-right','data' => ['class' => 'h-4 w-4']]); ?>
<?php $component->withName('svgs.arrow-right'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'h-4 w-4']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </button>
                <div class="flex-1">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.datepicker-without-label','data' => ['wire:model' => 'date','class' => 'w-full','name' => 'date','type' => 'text','clearButton' => false]]); ?>
<?php $component->withName('inputs.datepicker-without-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'date','class' => 'w-full','name' => 'date','type' => 'text','clear-button' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
            </div>
        </div>

        <?php if (\Illuminate\Support\Facades\Blade::check('role', ['owner', 'manager'])): ?>
        <div class="w-full md:w-1/3 lg:w-1/4">
            <div class="mx-2">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select-without-label2','data' => ['wire:model' => 'user_id','class' => 'w-full','name' => 'user_id']]); ?>
<?php $component->withName('inputs.select-without-label2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'user_id','class' => 'w-full','name' => 'user_id']); ?>
                    <?php //  <option value="{{ auth()->id() }}" selected > {{ auth()->user()->firstname }}  {{ auth()->user()->lastname }}</option>
                    ?>

                    <?php $__currentLoopData = $login; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($log->id); ?>">
                        <?php echo e($log->full_name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>">
                        <?php echo e($user->full_name); ?>

                        
                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
        </div>
        <div class="sm:flex new-activity-button pb-0">
            <button wire:click="$emit('activityCreate')" type="button" class="w-full sm:w-auto mt-4 sm:mt-0 h-10 text-sm flex items-center rounded-md bg-blue-600 text-white pl-4 pr-6 hover:bg-blue-500 focus:outline-none active:bg-blue-700 transition duration-150 ease-in-out">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.plus','data' => ['class' => 'w-5 h-5 mr-1']]); ?>
<?php $component->withName('svgs.plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 mr-1']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                Add time
            </button>
        </div>

        <?php endif; ?>

    </div>

    <div class="flex flex-wrap -mx-4">
        <div class="w-full xl:w-1/1">
            <div class="bg-white rounded-md border p-6 mx-4 mb-8">
                <div class="w-full xl:w-1/2">
                    <div class="w-full xl:w-1/2 flex flex-wrap">
                        <div class="w-full xl:w-1/2">
                            <h4 class="text-sm  xl:tracking-widest uppercase mb-2">
                                Time
                            </h3>
                            <span class="text-lg text-gray-800">
                                <?php echo e(gmdate('H:i', $timeToday)); ?>

                            </span>
                            <br>
                            <span class="text-sm text-gray-800">
                                TOTAL WORKED
                            </span>
                        </div>

                        <div class="w-full xl:w-1/2">
                            <h3 class="text-sm text-blue-500 xl:tracking-widest uppercase mb-2">
                                 
                            </h3>
                            <div class="flex items-center text-sm <?php echo e($totalPreviuosTimeState=='more'? 'text-red-500' :'text-green-500'); ?>">
                                <?php if($totalPreviuosTimeState=='more'): ?>
                                <img style="margin-top:-2px;margin-right: 10px;" src="https://d2elkgkdx2cp5d.cloudfront.net/assets/global/arrow_red-7d7d05038fc89ddb147974ea866c4c303ba2bfccc049b6bf073d4709f0d026bb.svg">
                                <?php else: ?>
                                <img style="margin-top: -2px;margin-right: 10px;"  src="https://d2elkgkdx2cp5d.cloudfront.net/assets/global/arrow_green-bb4267018493d26d5ef23d41f52f674046a789343cd449b2dace465966c00883.svg">
                                <?php endif; ?>
                                <span class="text-lg">
                                    <?php echo e(gmdate('H:i', $totalPreviuosTime)); ?>

                                </span>
                            </div>


                            <span class="text-sm text-gray-800">
                                TO PREV DAY
                            </span>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>





    

    <?php
    $countActivity = 0;
    ?>
    <?php if($activitiesGroup->count()): ?>
    
    <?php $__currentLoopData = $activitiesGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time => $activities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="text-gray-500 text-xs py-4 activities">
        <?php echo e($time); ?>

    </div>
    <div class="flex flex-wrap -mx-4 activities">
        <?php if($activity = $activities->first(function ($activity, $key) {
        return $activity->start_datetime->format('i') == '00';
        })): ?>
        <?php
        ++$countActivity;
        ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.activities.card','data' => ['activity' => $activity,'countActivity' => $countActivity]]); ?>
<?php $component->withName('activities.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['activity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activity),'countActivity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($countActivity)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php else: ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.activities.empty','data' => []]); ?>
<?php $component->withName('activities.empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if($activity = $activities->first(function ($activity, $key) {
        return $activity->start_datetime->format('i') == '10';
        })): ?>
        <?php
        ++$countActivity;
        ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.activities.card','data' => ['activity' => $activity,'countActivity' => $countActivity]]); ?>
<?php $component->withName('activities.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['activity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activity),'countActivity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($countActivity)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php else: ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.activities.empty','data' => []]); ?>
<?php $component->withName('activities.empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if($activity = $activities->first(function ($activity, $key) {
        return $activity->start_datetime->format('i') == '20';
        })): ?>
        <?php
        ++$countActivity;
        ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.activities.card','data' => ['activity' => $activity,'countActivity' => $countActivity]]); ?>
<?php $component->withName('activities.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['activity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activity),'countActivity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($countActivity)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php else: ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.activities.empty','data' => []]); ?>
<?php $component->withName('activities.empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if($activity = $activities->first(function ($activity, $key) {
        return $activity->start_datetime->format('i') == '30';
        })): ?>
        <?php
        ++$countActivity;
        ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.activities.card','data' => ['activity' => $activity,'countActivity' => $countActivity]]); ?>
<?php $component->withName('activities.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['activity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activity),'countActivity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($countActivity)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php else: ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.activities.empty','data' => []]); ?>
<?php $component->withName('activities.empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if($activity = $activities->first(function ($activity, $key) {
        return $activity->start_datetime->format('i') == '40';
        })): ?>
        <?php
        ++$countActivity;
        ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.activities.card','data' => ['activity' => $activity,'countActivity' => $countActivity]]); ?>
<?php $component->withName('activities.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['activity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activity),'countActivity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($countActivity)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php else: ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.activities.empty','data' => []]); ?>
<?php $component->withName('activities.empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if($activity = $activities->first(function ($activity, $key) {
        return $activity->start_datetime->format('i') == '50';
        })): ?>
        <?php
        ++$countActivity;
        ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.activities.card','data' => ['activity' => $activity,'countActivity' => $countActivity]]); ?>
<?php $component->withName('activities.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['activity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activity),'countActivity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($countActivity)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php else: ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.activities.empty','data' => []]); ?>
<?php $component->withName('activities.empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.states.empty-data2','data' => []]); ?>
<?php $component->withName('states.empty-data2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <div id="miModal" class="modal">
        <div class="modal-contenido">
            <a href="#">X</a>
            <div class="py-4 pl-4">
                <h4 class="text-gray-600">
                    <i class="fa fa-exclamation-circle"></i> Your team has not tracked any time.
                </h4>
            </div>

            <h1 class="py-4"><b>Getting Started</b></h1>
            <div class="list">
                <ul>
                    <ol>1. Each team member needs to open their invite email and click the accept link.</li>
                        <ol>2. Next they must download the <a class="text-blue-600" href="https://neostaff.app/download">NeoStaff App.</a></li>
                            <ol>3. Finally they have to install the app and use it to track time to a project.</li>
                </ul>
            </div>
            <h1 class="py-4"><b>Your Organizations</b></h1>
            <h1 class="pb-2"><b><?php echo $account[0]->name . ' team members'; ?> </b></h1>
            <h4 class="text-gray-400 py-4"><i class="fas fa-info-circle"></i> Time can also be added manually on the
                timesheets page.</h4>
        </div>
    </div>

    <style>
        .modal-contenido {
            background-color: white;
            border-radius: 8px;
            width: 650px;
            height: 400px;
            padding: 10px 20px;
            margin: 0 auto;
            position: relative;
        }

        .list {
            margin-left: 30px;
        }

        .modal {
            background-color: rgba(0, 0, 0, 0.5);
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            opacity: 0;
            pointer-events: none;
            transition: all 1s;
        }

        #miModal:target {
            opacity: 1;
            pointer-events: auto;
        }
    </style>


    <?php endif; ?>



    <?php $__env->startPush('modals'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.tasks.tasks-form')->html();
} elseif ($_instance->childHasBeenRendered('uHnPUbs')) {
    $componentId = $_instance->getRenderedChildComponentId('uHnPUbs');
    $componentTag = $_instance->getRenderedChildComponentTagName('uHnPUbs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uHnPUbs');
} else {
    $response = \Livewire\Livewire::mount('accounts.tasks.tasks-form');
    $html = $response->html();
    $_instance->logRenderedChild('uHnPUbs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('modals'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.screenshots.screenshots-show-carousel')->html();
} elseif ($_instance->childHasBeenRendered('ab9K6S6')) {
    $componentId = $_instance->getRenderedChildComponentId('ab9K6S6');
    $componentTag = $_instance->getRenderedChildComponentTagName('ab9K6S6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ab9K6S6');
} else {
    $response = \Livewire\Livewire::mount('accounts.screenshots.screenshots-show-carousel');
    $html = $response->html();
    $_instance->logRenderedChild('ab9K6S6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('modals'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('track-modal')->html();
} elseif ($_instance->childHasBeenRendered('OSaHyVf')) {
    $componentId = $_instance->getRenderedChildComponentId('OSaHyVf');
    $componentTag = $_instance->getRenderedChildComponentTagName('OSaHyVf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OSaHyVf');
} else {
    $response = \Livewire\Livewire::mount('track-modal');
    $html = $response->html();
    $_instance->logRenderedChild('OSaHyVf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('modals'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.activities.delete-activity-modal')->html();
} elseif ($_instance->childHasBeenRendered('gVx2AV4')) {
    $componentId = $_instance->getRenderedChildComponentId('gVx2AV4');
    $componentTag = $_instance->getRenderedChildComponentTagName('gVx2AV4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gVx2AV4');
} else {
    $response = \Livewire\Livewire::mount('accounts.activities.delete-activity-modal');
    $html = $response->html();
    $_instance->logRenderedChild('gVx2AV4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('modals'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accounts.activities.delete-image-activity-modal')->html();
} elseif ($_instance->childHasBeenRendered('KpFXLPQ')) {
    $componentId = $_instance->getRenderedChildComponentId('KpFXLPQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('KpFXLPQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KpFXLPQ');
} else {
    $response = \Livewire\Livewire::mount('accounts.activities.delete-image-activity-modal');
    $html = $response->html();
    $_instance->logRenderedChild('KpFXLPQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php $__env->stopPush(); ?>
</div>
<style>
    .new-activity-button {
        display: flex !important;
        justify-content: flex-end !important;
    }
</style>


<script>




//        var listActivityImg = document.getElementsByClassName("activity-img");

// listActivityImg.forEach(item => {
//     item.classList.remove('group-hover:opacity-100');
// });

</script><?php /**PATH /home/medianeo/neostaff/resources/views/livewire/accounts/activities/index.blade.php ENDPATH**/ ?>
<?php $attributes = $attributes->exceptProps(['task','project']); ?>
<?php foreach (array_filter((['task','project']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div wire:click.stop="$emit('taskShow', <?php echo e($task->id); ?>)" class="w-full bg-white py-5 rounded-md border mb-3 cursor-pointer hover:shadow-md">
    <div class="hidden md:flex items-center text-sm">
        <div class="flex-1 px-3 text-gray-700 font-montserrat font-semibold">
            <?php echo e($task->title); ?>

        </div>
        <div class="w-44 px-3">
            <div class="flex items-center">
                <?php if($task->user): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.user.avatar','data' => []]); ?>
<?php $component->withName('user.avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <span class="ml-3 block text-left font-montserrat text-xs font-semibold text-gray-500"><?php echo e($task->user->firstname); ?> <?php echo e($task->user->lastname); ?></span>
                <?php else: ?>
                    <span class="text-xs text-gray-500">Not assigned</span>
                <?php endif; ?>
            </div>
        </div>

        <h4 class="w-32 px-3 text-xs text-gray-500">
            <?php echo e($task->project->title); ?>

        </h4>


        <div class="w-32 px-3 text-xs text-gray-500">
            <?php if($task->due_date): ?>
                <?php echo e($task->due_date->format('M d, Y')); ?>

            <?php else: ?>
                No due date
            <?php endif; ?>
        </div>
        
        <div class="w-32 px-3 text-xs text-gray-500">
             <?php echo e(gmdate("H:i:s", App\Models\Activity::where('project_id',$task->project_id)->where('task_id',$task->id)->sum('seconds'))); ?>

        </div>
        <div class="w-32 px-3">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.tasks.status-badge','data' => ['status' => $task->completed]]); ?>
<?php $component->withName('tasks.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($task->completed)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <div class="w-20 px-3 flex justify-end">
            <?php if (\Illuminate\Support\Facades\Blade::check('role', ['owner', 'manager'], optional($task->user)->id)): ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.tasks.actions','data' => ['task' => $task]]); ?>
<?php $component->withName('tasks.actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['task' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($task)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="text-sm block md:hidden">
        <div class="flex items-start justify-between">
            <div class="px-4 flex-1 truncate">
                <div class="flex items-center justify-between mb-3">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.tasks.status-badge','data' => ['status' => $task->completed]]); ?>
<?php $component->withName('tasks.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($task->completed)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <span class="text-xs text-gray-500">
                        <?php if($task->due_date): ?>
                            <?php echo e($task->due_date->format('M d, Y')); ?>

                        <?php else: ?>
                            No due date
                        <?php endif; ?>
                    </span>
                </div>
                <div class="text-gray-700 font-montserrat font-semibold truncate">
                    <?php echo e($task->title); ?>

                </div>
			
            </div>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.tasks.actions','data' => ['task' => $task]]); ?>
<?php $component->withName('tasks.actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['task' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($task)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/tasks/table-row.blade.php ENDPATH**/ ?>
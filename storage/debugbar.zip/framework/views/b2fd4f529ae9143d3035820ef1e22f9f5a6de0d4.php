<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/medianeo/neostaff/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>
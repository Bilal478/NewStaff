<?php $attributes = $attributes->exceptProps(['team', 'users', 'usersCount']); ?>
<?php foreach (array_filter((['team', 'users', 'usersCount']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
    <article
        wire:click="teamShow(<?php echo e($team->id); ?>)"
        class="bg-white mx-4 mb-8 rounded-md border shadow-sm px-6 py-4 h-30 flex flex-col justify-between items-start cursor-pointer hover:shadow-md"
    >
        <div class="w-full">
            <div class="mb-4 flex items-center justify-end">
                <?php if (\Illuminate\Support\Facades\Blade::check('role', ['owner', 'manager'])): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdowns.context-menu','data' => ['class' => '-mr-2']]); ?>
<?php $component->withName('dropdowns.context-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => '-mr-2']); ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdowns.context-menu-item','data' => ['wire:click.stop' => '$emit(\'teamsEdit\', '.e($team->id).')','name' => 'Edit','svg' => 'svgs.edit']]); ?>
<?php $component->withName('dropdowns.context-menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.stop' => '$emit(\'teamsEdit\', '.e($team->id).')','name' => 'Edit','svg' => 'svgs.edit']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdowns.context-menu-item','data' => ['wire:click.stop' => 'teamArchive('.e($team->id).')','name' => 'Delete','svg' => 'svgs.trash']]); ?>
<?php $component->withName('dropdowns.context-menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.stop' => 'teamArchive('.e($team->id).')','name' => 'Delete','svg' => 'svgs.trash']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>
            <h4 class="font-montserrat font-semibold text-sm text-gray-700 pb-4 truncate">
                <?php echo e($team->title); ?>

            </h4>
        </div>
        <div class="w-full flex items-center justify-between">
            <div class="flex items-center space-x-1">
                <?php if($usersCount >= 1): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.user.avatar','data' => []]); ?>
<?php $component->withName('user.avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php endif; ?>
                <?php if($usersCount >= 2): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.user.avatar','data' => []]); ?>
<?php $component->withName('user.avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php endif; ?>
                <?php if($usersCount > 2): ?>
                    <div class="h-8 w-8 bg-indigo-400 rounded-full text-white flex items-center justify-center text-xs tracking-wider">
                        +<?php echo e($usersCount - 2); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </article>
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/teams/card.blade.php ENDPATH**/ ?>
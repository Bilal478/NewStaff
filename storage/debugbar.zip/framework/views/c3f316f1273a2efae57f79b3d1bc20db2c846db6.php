<div class="w-full">
    <?php if (\Illuminate\Support\Facades\Blade::check('role', ['owner', 'manager'])): ?>
        <div class="pb-6 mb-2 border-b">
            <form wire:submit.prevent="add" class="flex items-center space-x-2">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select-without-label','data' => ['wire:model.lazy' => 'userId','name' => 'userId','class' => 'flex-1']]); ?>
<?php $component->withName('inputs.select-without-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'userId','name' => 'userId','class' => 'flex-1']); ?>
                    <option value="">Select member</option>
                    <?php $__currentLoopData = $usersOut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>">
                            <?php echo e($user->full_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if($userId): ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.buttons.blue-inline','data' => ['type' => 'submit','class' => 'h-10']]); ?>
<?php $component->withName('buttons.blue-inline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'h-10']); ?>
                    Add
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php else: ?>
                <button class="button text-sm flex items-center rounded-md   text-white px-6 py-2   focus:outline-none   transition duration-150 ease-in-out h-10" disabled>Add</button>

                <?php endif; ?>
            </form>
        </div>
    <?php endif; ?>

    <div class="h-96 overflow-y-scroll">
        <?php $__currentLoopData = $usersIn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.members.compact','data' => ['user' => $user,'key' => $user->id,'wire:click' => 'remove('.e($user->id).')','class' => 'p-2 my-2 rounded-md cursor-default hover:bg-gray-100']]); ?>
<?php $component->withName('members.compact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user),'key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user->id),'wire:click' => 'remove('.e($user->id).')','class' => 'p-2 my-2 rounded-md cursor-default hover:bg-gray-100']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->startPush('style'); ?>
    <style>
  
.button{
    background: gray
}
    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/medianeo/neostaff/resources/views/livewire/accounts/departments/users-form.blade.php ENDPATH**/ ?>
<?php $attributes = $attributes->exceptProps([
    'name',
    'type' => 'text',
    'placeholder' => '',
    'clearButton' => true,
]); ?>
<?php foreach (array_filter(([
    'name',
    'type' => 'text',
    'placeholder' => '',
    'clearButton' => true,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="<?php echo e($attributes->get('class')); ?>">
    <div class="relative text-gray-400 focus-within:text-blue-600 rounded-md shadow-sm">
        <input
            x-data
            x-ref="datepicker"
            x-init="new Litepicker({
                element: $refs.datepicker,
                maxDate: new Date(),
                format: 'YYYY-MM-DD',
                setup: (picker) => {
                    picker.on('selected', (date) => {
                        $dispatch('input', moment(date.dateInstance).format('YYYY-MM-DD'));
                    });
                },
                <?php echo e($clearButton ?
                'resetButton: () => {
                    let btn = document.createElement("button");
                    btn.innerText = "Clear";
                    btn.addEventListener("click", (evt) => {
                        evt.preventDefault();
                        $dispatch("input", null);
                    });

                    return btn;
                },' : ''); ?>

            })"
            id="<?php echo e($name); ?>"
            type="<?php echo e($type); ?>"
            placeholder="<?php echo e($placeholder); ?>"
            <?php echo e($attributes->whereStartsWith('wire:model')); ?>

            <?php echo e($attributes->whereStartsWith('autofocus')); ?>

            <?php echo e($attributes->whereStartsWith('required')); ?>

            class="h-10 appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md placeholder-gray-400 text-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out text-sm leading-5"
        />

        <div class="absolute inset-y-0 right-0 flex items-center justify-center pr-3 pointer-events-none">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.calendar','data' => ['class' => 'w-5 h-5']]); ?>
<?php $component->withName('svgs.calendar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
    </div>

    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<?php if (! $__env->hasRenderedOnce('2c6bc3d0-a6f2-4746-a327-b5709f760044')): $__env->markAsRenderedOnce('2c6bc3d0-a6f2-4746-a327-b5709f760044'); ?>
    <?php $__env->startPush('scripts'); ?>
        <script src="https://cdn.jsdelivr.net/npm/litepicker@v2.0.x/dist/litepicker.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/inputs/datepicker-without-label-two.blade.php ENDPATH**/ ?>
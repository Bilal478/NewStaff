<div wire:ignore class="pb-6 <?php echo e($attributes->get('class')); ?>">
    <label for="<?php echo e($name); ?>" class="block text-sm text-gray-500 leading-5">
        <?php echo e($label); ?> <?php if($attributes->has('required')): ?><span class="text-red-500 text-xs">*</span><?php endif; ?>
    </label>
    <div class="" style="border: 1px solid #e5e5e5; border-radius:3px; width:100%; margin-bottom:15px; padding: 3px 0px;">
        <select id="<?php echo e($name); ?>" style="width: 100%" <?php echo e($attributes->whereStartsWith('wire:model')); ?>

            <?php echo e($attributes->whereStartsWith('autofocus')); ?> <?php echo e($attributes->whereStartsWith('required')); ?>>
            <?php echo e($slot); ?>

			
        </select>
    </div>

    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php $__env->startPush('scripts'); ?>

<script>
    document.addEventListener('livewire:load', function (event) {

            Livewire.hook('message.processed', () => {

                $('#<?php echo e($name); ?>').select2();

            });

        });

            $('#<?php echo e($name); ?>').on('change', function (e) {
            let elementName = $(this).attr('id');
            var data = $(this).select2("val");
            window.livewire.find('<?php echo e($_instance->id); ?>').set(elementName, data);
        });

        $('#<?php echo e($name); ?>').select2();

</script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/inputs/select_two.blade.php ENDPATH**/ ?>
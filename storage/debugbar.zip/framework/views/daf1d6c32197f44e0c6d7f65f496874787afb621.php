<?php $__env->startComponent('mail::message'); ?>


Hello!

You are receiving this email because <?php echo e($member); ?> has accepted your invitation!

Now you can assign projects, tasks and collaborate with your new team member.

Thanks

Your friends,

<a href="https://neostaff.app/support">support@neostaff.app</a>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/medianeo/neostaff/resources/views/emails/notification/notification.blade.php ENDPATH**/ ?>
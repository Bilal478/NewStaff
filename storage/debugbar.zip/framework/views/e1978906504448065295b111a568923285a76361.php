<div x-data="{ open: false }" class="relative border-t">
    <button x-on:click="open = true" type="button" class="w-full px-6 py-3 flex items-center hover:bg-gray-100" :class="{ 'bg-gray-100': open === true }">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.user.avatar','data' => []]); ?>
<?php $component->withName('user.avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <span class="flex-1 text-left inline-block text-sm text-gray-700 pl-2 truncate">
            <?php echo e($user->full_name); ?>

        </span>
    </button>

    <div
        x-show="open"
        x-transition:enter="transition ease-out duration-150"
        x-transition:enter-start="opacity-0 transform scale-90"
        x-transition:enter-end="opacity-100 transform scale-100"
        x-on:click.away="open = false"
        x-cloak
        class="absolute bg-white inset-x-0 mx-2 mb-1 border shadow-md rounded-md"
        style="bottom: 100%;"
    >
        <ul class="text-gray-700 text-xs">
            <li class="p-1">
                <a href="<?php echo e(route('profile.edit')); ?>" class="px-3 py-1 rounded-md leading-6 flex items-center hover:bg-gray-100 hover:text-blue-600">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.user','data' => ['class' => 'w-4 h-4 mr-2']]); ?>
<?php $component->withName('svgs.user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 mr-2']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <span class="text-gray-700">My Profile</span>
                </a>
            </li>
            <li class="p-1">
                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="px-3 py-1 rounded-md leading-6 flex items-center hover:bg-gray-100 hover:text-blue-600">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.logout','data' => ['class' => 'w-4 h-4 mr-2']]); ?>
<?php $component->withName('svgs.logout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 mr-2']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <span class="text-gray-700">Logout</span>
                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/livewire/accounts/profile/info.blade.php ENDPATH**/ ?>
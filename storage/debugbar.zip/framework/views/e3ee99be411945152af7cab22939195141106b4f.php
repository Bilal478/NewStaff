<?php $attributes = $attributes->exceptProps(['activity', 'countActivity']); ?>
<?php foreach (array_filter((['activity', 'countActivity']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if(isset($countActivity)): ?>
<?php endif; ?>
<div class="w-full sm:w-1/2 md:w-1/3 xl:w-1/6">
    <article class="bg-white mx-4 mb-8 rounded-md border shadow-sm hover:shadow-md article">
        <div class="relative group rounded-t-md overflow-hidden bg-black">
            <div
                class="activity-img flex items-center justify-center absolute inset-0 z-10 opacity-0 transition duration-500 ease-linear group-hover:opacity-100">
                
                <button
                    wire:click.stop="$emit('screenshotsShow', <?php echo e($activity->user_id); ?>,<?php echo e($activity->account_id); ?>,'<?php echo e($activity->date); ?>')"
                    onclick="currentSlide(<?php echo e($countActivity); ?>)" type="button"
                    class="bg-white font-montserrat font-semibold px-3 py-1 rounded-sm text-gray-700 text-xs">
                    View screens
                </button>
            </div>
            
            <div
                class="overflow-hidden object-cover h-28 rounded-t-md transition duration-300 transform ease-linear group-hover:scale-110 group-hover:opacity-60">
                <?php if($activity->screenshots): ?>
                    <?php if(count($activity->screenshots) > 0): ?>
                        <img style="" src="<?php echo e($activity->screenshots->first()->fullPath()); ?>" alt="">
                    <?php endif; ?>
                <?php endif; ?>
                <?php if(!$activity->screenshots): ?>
                    <img class="img_placeholder" src="activity_placeholder.png">
                <?php endif; ?>
            </div>

        </div>

        <div class="relative pt-6 pb-4">
            <div class="absolute w-full flex justify-center top-0 -mt-3 z-10">
                
            </div>


            <div class="px-4">
                <div class="flex mb-4 w-full">
                    <span class="text-xs text-gray-500"><?php echo e($activity->start_datetime->format('g:i: a')); ?> -
                        <?php echo e($activity->end_datetime->format('g:i: a')); ?></span>
                </div>
                <br>
                <div class="flex mb-4 w-3/5" style="float: right;
                margin-top: -36px;">
                    <?php if (\Illuminate\Support\Facades\Blade::check('role', ['owner', 'manager'])): ?>
                        <button type="button"
                            wire:click="$emit('trackEdit','<?php echo e($activity->id); ?>','<?php echo e($activity->date); ?>','<?php echo e($activity->start_datetime->format('H:i:s')); ?>','<?php echo e($activity->end_datetime->format('H:i:s')); ?>')">
                            <span class="text-xs text-blue-500">
                                <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24"
                                    stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z">
                                    </path>
                                </svg>
                            </span>
                        </button>
                        <button type="button" wire:click="$emit('deleteActivityShow',<?php echo e($activity->id); ?>)">
                            <span class="text-xs text-red-500">
                                <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24"
                                    stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16">
                                    </path>
                                </svg>
                            </span>
                        </button>
                        <button type="button" wire:click="$emit('deleteImageActivityShow',<?php echo e($activity->id); ?>)">
                            <span class="text-xs text-blue-500">
                                <svg version="1.0" xmlns="http://www.w3.org/2000/svg" style="color: rgb(226, 111, 3)"
                                    width="12.000000pt" height="12.000000pt" viewBox="0 0 20.000000 20.000000"
                                    preserveAspectRatio="xMidYMid meet">
                                    <g transform="translate(0.000000,20.000000) scale(0.026667,-0.025316)" fill="#000000"
                                        stroke="none">
                                        <path
                                            d="M131 730 c-46 -11 -100 -67 -111 -116 -12 -51 -12 -417 0 -468 11
                               -51 65 -105 116 -116 51 -12 417 -12 468 0 51 11 105 65 116 116 12 51 12 417
                               0 468 -11 51 -65 105 -116 116 -47 11 -426 11 -473 0z m494 -95 c24 -23 25
                               -29 25 -160 0 -74 -2 -135 -4 -135 -2 0 -23 24 -46 53 -48 59 -64 71 -84 60
                               -8 -4 -44 -45 -80 -90 -37 -46 -70 -83 -74 -83 -4 0 -38 23 -76 50 -38 28 -72
                               50 -76 50 -4 0 -32 -18 -63 -41 l-57 -40 0 156 c0 152 1 156 25 180 l24 25
                               231 0 231 0 24 -25z m-31 -354 c64 -80 72 -116 31 -156 l-24 -25 -231 0 -231
                               0 -24 25 c-43 42 -34 73 35 123 l60 44 76 -56 c42 -31 80 -56 83 -56 13 0 38
                               26 96 98 31 39 61 72 65 72 4 0 33 -31 64 -69z" />
                                    </g>
                                </svg>


                            </span>
                        </button>
                    <?php endif; ?>
                </div>
                

                <div class="relative mb-4">
                    <div class="w-full h-1 bg-gray-200 rounded-sm"></div>
                    <?php if($activity->total_activity_percentage >= 51): ?>
                        <div class="h-1 rounded-sm absolute top-0 left-0 bg-green-500"
                            style="width: <?php echo e($activity->total_activity_percentage); ?>%"></div>
                    <?php endif; ?>
                    <?php if($activity->total_activity_percentage >= 21 and $activity->total_activity_percentage <= 50): ?>
                        <div class="h-1 rounded-sm absolute top-0 left-00"
                            style="width: <?php echo e($activity->total_activity_percentage); ?>%;background-color: #fdd54ac4;"></div>
                    <?php endif; ?>
                    <?php if($activity->total_activity_percentage <= 20): ?>
                        <div class="h-1 rounded-sm absolute top-0 left-0 bg-red-500"
                            style="width: <?php echo e($activity->total_activity_percentage); ?>%"></div>
                    <?php endif; ?>

                    
                </div>

                <div class="flex items-center justify-center space-x-2">
                    <div class="flex items-center">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.keyboard','data' => ['class' => 'w-4 h-4 text-blue-500 mr-1']]); ?>
<?php $component->withName('svgs.keyboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 text-blue-500 mr-1']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        <span class="text-xs text-gray-500"><?php echo e($activity->keyboard_count); ?></span>
                    </div>

                    <div class="flex items-center">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.cursor','data' => ['class' => 'w-4 h-4 text-blue-500 mr-1']]); ?>
<?php $component->withName('svgs.cursor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 text-blue-500 mr-1']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        <span class="text-xs text-gray-500"><?php echo e($activity->mouse_count); ?></span>
                    </div>

                    <div class="flex items-center">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.computer','data' => ['class' => 'w-4 h-4 text-blue-500 mr-1']]); ?>
<?php $component->withName('svgs.computer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 text-blue-500 mr-1']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        <span class="text-xs text-gray-500"><?php echo e($activity->total_activity_percentage); ?>%</span>
                    </div>
                </div>
            </div>

        </div>
    </article>
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/activities/card.blade.php ENDPATH**/ ?>
<?php
use App\Models\User;

$user = Auth::user();

$user_email = $user->email;

?>

<?php $__env->startComponent('mail::message'); ?>

You have been invited to join the  <?php echo e($accountName); ?> team owned by <?php echo $user_email; ?>

on NeoStaff. To get started, accept the invite below: 

<?php $__env->startComponent('mail::button', ['url' => $url]); ?>
Accept Invitation
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>



Joining the team will give you access to the team's dashboard, including information 
about projects, tasks, teams, and more.<br>      
You can find answers to most questions and get in touch with us at 
<br>
<a href="https://neostaff.app/support">https://neostaff.app/support.</a> We’re here to help you at any step along the way.                  

Yours,<br>  
 The NeoStaff Team        

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/medianeo/neostaff/resources/views/emails/account/invite.blade.php ENDPATH**/ ?>
<?php $attributes = $attributes->exceptProps([
    'name' => '',
]); ?>
<?php foreach (array_filter(([
    'name' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="relative text-gray-400 focus-within:text-blue-600 <?php echo e($attributes->get('class')); ?>">
    <input
        id="<?php echo e($name); ?>"
        type="text"
        name="search"
        <?php echo e($attributes->whereStartsWith('wire:model')); ?>

        <?php echo e($attributes->whereStartsWith('placeholder')); ?>

        class="h-10 appearance-none block w-full pl-10 pr-3 py-2 border border-gray-300 shadow-sm rounded-md placeholder-gray-400 text-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-400 transition duration-150 ease-in-out text-sm leading-5"
    >
    <div class="absolute inset-y-0 left-0 flex items-center justify-center pl-3 pointer-events-none">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.svgs.search','data' => ['class' => 'w-5 h-5']]); ?>
<?php $component->withName('svgs.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
</div>
<?php /**PATH /home/medianeo/neostaff/resources/views/components/inputs/search.blade.php ENDPATH**/ ?>